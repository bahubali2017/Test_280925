import React from "react";
import { Switch, Route, useLocation } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { AuthProvider } from "./hooks/useAuth";
import { ProtectedRoute } from "./components/ProtectedRoute";
import { ToastProvider } from "./components/ToastProvider";
import LoginPage from "./pages/LoginPage";
import ChatPage from "./pages/ChatPage";
import NotFound from "./pages/not-found";

/**
 * Router component that handles application routing
 * @returns {JSX.Element} The Router component
 */
function Router() {
  const [location, setLocation] = useLocation();

  // Redirect to login if at root path
  if (location === '/') {
    setLocation('/login');
    return null;
  }

  return (
    <Switch location={location}>
      {/* Login route */}
      <Route path="/login" component={LoginPage} />
      
      {/* Protected chat route */}
      <Route path="/chat">
        <ProtectedRoute>
          <ChatPage />
        </ProtectedRoute>
      </Route>
      
      {/* 404 route */}
      <Route component={NotFound} />
    </Switch>
  );
}

/**
 * Main application component
 * Sets up providers and renders the Router
 * @returns {JSX.Element} The App component
 */
export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ToastProvider>
        <AuthProvider>
          <Router />
        </AuthProvider>
      </ToastProvider>
    </QueryClientProvider>
  );
}