import React, { useState, useEffect, useCallback } from 'react';
import { cn } from '../lib/utils';

/**
 * Props for the Input component
 * @typedef {object} InputProps
 * @property {string} [className] - Additional CSS classes
 * @property {string} [type="text"] - Input type attribute
 * @property {number} [maxLength] - Maximum input length
 * @property {boolean} [showCharCount=false] - Whether to show character count
 * @property {boolean} [multiline=false] - Whether pressing Enter creates a new line (with Shift+Enter) or submits
 * @property {Function} [onEnterPress] - Function to call when Enter is pressed (in singleline mode)
 * @property {React.InputHTMLAttributes<HTMLInputElement>} props - HTML input attributes
 */

/**
 * Enhanced Input component for forms with character counting and Enter behavior
 * @param {object} props - The input props
 * @param {string} [props.className] - Additional CSS classes
 * @param {string} [props.type="text"] - Input type attribute
 * @param {number} [props.maxLength] - Maximum input length
 * @param {boolean} [props.showCharCount=false] - Whether to show character count
 * @param {boolean} [props.multiline=false] - Whether pressing Enter creates a new line (with Shift+Enter) or submits
 * @param {Function} [props.onEnterPress] - Function to call when Enter is pressed (in singleline mode)
 * @param {React.Ref} ref - Forwarded ref
 * @returns {JSX.Element} The enhanced Input component
 */
export const Input = React.forwardRef(function Input({ 
  className, 
  type = "text", 
  maxLength, 
  showCharCount = false,
  multiline = false,
  onEnterPress,
  ...props 
}, ref) {
  // Track character count
  const [charCount, setCharCount] = useState(props.value ? String(props.value).length : 0);
  
  // Update character count when value changes
  useEffect(() => {
    setCharCount(props.value ? String(props.value).length : 0);
  }, [props.value]);
  
  // Handle Enter key press
  const handleKeyDown = useCallback((e) => {
    // If props already has onKeyDown, call it first
    if (props.onKeyDown) {
      props.onKeyDown(e);
    }
    
    // Handle Enter behavior - if not multiline or if Shift+Enter in multiline
    if (e.key === 'Enter') {
      if (!multiline || (multiline && e.shiftKey)) {
        if (onEnterPress) {
          e.preventDefault();
          onEnterPress(e);
        }
      }
    }
  }, [multiline, onEnterPress, props.onKeyDown]);
  
  // Determine character count color
  const getCountColor = () => {
    if (!maxLength) return 'text-gray-400';
    
    const ratio = charCount / maxLength;
    if (ratio >= 0.9) return 'text-red-500';
    if (ratio >= 0.75) return 'text-amber-500';
    return 'text-gray-400';
  };
  
  return (
    <div className="relative w-full">
      <input
        type={type}
        maxLength={maxLength}
        className={cn(
          "flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background",
          "file:border-0 file:bg-transparent file:text-sm file:font-medium",
          "placeholder:text-muted-foreground",
          "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
          "disabled:cursor-not-allowed disabled:opacity-50",
          showCharCount && maxLength && "pr-16",
          className
        )}
        ref={ref}
        onKeyDown={handleKeyDown}
        {...props}
      />
      
      {showCharCount && (
        <div 
          className={cn(
            "absolute right-3 top-1/2 -translate-y-1/2 text-xs font-mono",
            getCountColor()
          )}
        >
          {maxLength ? `${charCount}/${maxLength}` : charCount}
        </div>
      )}
    </div>
  );
});