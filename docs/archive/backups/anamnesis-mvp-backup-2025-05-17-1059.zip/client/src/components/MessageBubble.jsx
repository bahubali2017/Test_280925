import React from 'react';

/**
 * Helper to format message content with line breaks
 * @param {string} content - The message content
 * @param {boolean} [isStreaming=false] - Whether content is being streamed
 * @param {string} [partialContent=''] - Partial content for streaming display
 * @returns {JSX.Element|null} Formatted content with line breaks
 */
function formatMessageContent(content, isStreaming = false, partialContent = '', status = 'sent') {
  // If streaming and status is not 'delivered', display the partial content
  // Otherwise show the full content
  const displayContent = (isStreaming && status !== 'delivered') 
    ? (partialContent || content) 
    : content;
  
  if (!displayContent) return null;
  
  // Convert newlines to JSX without using React.Fragment
  // This avoids the React.Fragment attribute issue
  const formattedContent = [];
  const lines = displayContent.split('\n');
  
  for (let i = 0; i < lines.length; i++) {
    // Add the line
    formattedContent.push(
      <span key={`line-${i}`}>{lines[i]}</span>
    );
    
    // Add line break if not the last line
    if (i < lines.length - 1) {
      formattedContent.push(<br key={`br-${i}`} />);
    }
  }
  
  // Only show typing indicator if streaming is active and message is not delivered
  const showTypingIndicator = isStreaming && status !== 'delivered';
  
  // Use a stable, smooth animation instead of potentially flickery one
  return (
    <div className="relative" data-status={status}>
      {formattedContent}
      {showTypingIndicator && (
        <span className="typing-indicator ml-1">
          <span className="dot"></span>
          <span className="dot"></span>
          <span className="dot"></span>
        </span>
      )}
    </div>
  );
}

/**
 * Format a timestamp into a readable format
 * @param {Date} date - The date to format
 * @returns {string} The formatted date string
 */
function formatTimestamp(date) {
  if (!date || !(date instanceof Date) || isNaN(date)) {
    return '';
  }
  
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);
  
  // Format time as HH:MM
  const timeString = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  
  if (date >= today) {
    return `Today, ${timeString}`;
  } else if (date >= yesterday) {
    return `Yesterday, ${timeString}`;
  } else {
    return date.toLocaleDateString([], { 
      month: 'short', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }
}

/**
 * Props for the MessageBubble component
 * @typedef {object} MessageBubbleProps
 * @property {string} message - The message content
 * @property {boolean} isUser - Whether the message is from the user
 * @property {Date} [timestamp] - When the message was sent
 * @property {boolean} [isError] - Whether this is an error message
 * @property {boolean} [isHighRisk] - Whether this is a high-risk medical query
 * @property {object} [metadata] - Additional message metadata
 * @property {object} [metadata.queryIntent] - Query intent analysis results
 * @property {string} [originalMessage] - The original message that failed (for error messages)
 * @property {Function} [onRetry] - Function to call when retry button is clicked
 * @property {Function} [onFollowUpClick] - Function to call when a follow-up suggestion is clicked
 * @property {boolean} [showFollowUps=false] - Whether to show follow-up suggestions
 * @property {boolean} [isFirst=false] - Whether this is the first message in a sequence 
 * @property {boolean} [isLast=false] - Whether this is the last message in a sequence
 * @property {string} [className] - Additional CSS classes
 * @property {boolean} [isStreaming=false] - Whether this message is being streamed character by character
 * @property {string} [partialContent] - Partial content during streaming
 * @property {string} [status] - Message status (sent, delivered, failed)
 */

/**
 * Message bubble component for chat messages
 * @param {object} props - The message bubble props
 * @param {string} props.message - The message content
 * @param {boolean} props.isUser - Whether the message is from the user
 * @param {Date} [props.timestamp] - When the message was sent
 * @param {boolean} [props.isError=false] - Whether this is an error message
 * @param {boolean} [props.isHighRisk=false] - Whether this is a high-risk medical query
 * @param {object} [props.metadata] - Additional message metadata
 * @param {string} [props.originalMessage] - The original message that failed (for error messages)
 * @param {Function} [props.onRetry] - Function to call when retry button is clicked
 * @param {Function} [props.onFollowUpClick] - Function to call when a follow-up suggestion is clicked
 * @param {boolean} [props.showFollowUps=false] - Whether to show follow-up suggestions
 * @param {boolean} [props.isFirst=false] - Whether this is the first message in a sequence
 * @param {boolean} [props.isLast=false] - Whether this is the last message in a sequence
 * @param {string} [props.className] - Additional CSS classes
 * @param {boolean} [props.isStreaming=false] - Whether this message is being streamed character by character
 * @param {string} [props.partialContent] - Partial content during streaming
 * @param {string} [props.status] - Message status (sent, delivered, failed)
 * @returns {JSX.Element} The MessageBubble component
 */
export function MessageBubble({
  message,
  isUser,
  timestamp,
  isError = false,
  isHighRisk = false,
  metadata = {},
  originalMessage,
  onRetry,
  onFollowUpClick,
  onStopAI,
  isStoppingAI = false,
  showFollowUps = false,
  isFirst = false,
  isLast = false,
  className,
  isStreaming = false,
  partialContent = '',
  status = 'sent',
}) {
  // Add console log to verify this component is rendering
  console.log("🟨 ACTIVE MESSAGE COMPONENT", { isUser, status });
  // Determine role for accessibility
  const roleAttribute = isUser 
    ? 'user message' 
    : isError 
      ? 'error message'
      : 'assistant message';
  
  // Determine if we should show the full disclaimer alert
  const showHighRiskAlert = !isUser && metadata?.isHighRisk;
  
  // Set appropriate styling based on message type with enhanced dark mode support and improved contrast
  // DIRECT FIX: Force white text on user messages for all themes to ensure readability
  const bubbleStyle = isUser
    ? "bg-blue-700 text-white dark:bg-blue-600 dark:text-white shadow-md"
    : isError
      ? "bg-destructive/10 text-destructive dark:bg-destructive/20 dark:text-destructive-foreground border border-destructive/20"
      : status === 'cancelled'
        ? "bg-secondary/80 dark:bg-secondary/30 text-foreground dark:text-foreground shadow-sm border-l-2 border-amber-500"
        : "bg-secondary/80 dark:bg-secondary/30 text-foreground dark:text-foreground shadow-sm";
  
  // Generate follow-up suggestions based on message context
  const getFollowUpSuggestions = () => {
    // Default medical-focused follow-up suggestions
    const defaultSuggestions = [
      "What symptoms should I watch for?",
      "Are there any home remedies?",
      "When should I see a doctor?",
      "Is this condition contagious?",
    ];
    
    // If this is a symptom-based query, suggest more specific follow-ups
    if (metadata?.queryIntent?.isSymptomBased) {
      return [
        "What could be causing these symptoms?",
        "How long should I expect this to last?",
        "Are there any warning signs I should watch for?",
        "What tests might a doctor recommend?"
      ];
    }
    
    // If this is a professional query, suggest more clinical follow-ups
    if (metadata?.queryIntent?.isProfessionalQuery) {
      return [
        "What are the diagnostic criteria?",
        "Are there any recent treatment guideline updates?",
        "What's the typical prognosis?",
        "Are there any significant drug interactions?"
      ];
    }
    
    return defaultSuggestions;
  };

  // Determine bubble styling based on sequence position
  const bubbleRounding = isUser
    ? isFirst && isLast
      ? "rounded-lg"
      : isFirst
        ? "rounded-t-lg rounded-bl-lg rounded-br-sm"
        : isLast
          ? "rounded-b-lg rounded-tl-lg rounded-tr-sm"
          : "rounded-l-lg rounded-tr-sm rounded-br-sm"
    : isFirst && isLast
      ? "rounded-lg"
      : isFirst
        ? "rounded-t-lg rounded-br-lg rounded-bl-sm"
        : isLast
          ? "rounded-b-lg rounded-tr-lg rounded-tl-sm"
          : "rounded-r-lg rounded-tl-sm rounded-bl-sm";
  
  // Y-padding based on position in sequence with enhanced spacing
  const yPadding = isFirst && !isLast
    ? "pt-3 pb-2.5"
    : !isFirst && isLast
      ? "pt-2.5 pb-3"
      : isFirst && isLast
        ? "py-3"
        : "py-2.5";
        
  // Add animation classes based on message state and status
  // Avoid using pulse animation on the whole bubble to prevent flickering
  const animationClass = isFirst 
    ? "animate-slide-in" 
    : "animate-fade-in";
    
  // Add a data attribute for styling/debugging
  const bubbleStatus = isStreaming && status !== 'delivered'
    ? 'streaming'
    : status;
  
  return (
    <div 
      className={cn(
        isFirst ? "mt-3" : "mt-1.5", 
        isLast ? "mb-3" : "mb-1.5", 
        className
      )}
      role="listitem"
      aria-label={roleAttribute}
      data-status={bubbleStatus}
    >
      {isUser ? (
        <div className="flex justify-end">
          <div
            className={cn(
              `bg-blue-700 text-white ${bubbleRounding} px-4 ${yPadding} max-w-[85%] md:max-w-[75%] text-body relative transition-all duration-200 ${animationClass} shadow-md`,
              isStreaming && status !== 'delivered' ? 'bubble--streaming' : '',
              className
            )}
            data-bubble-status={bubbleStatus}
          >
            {formatMessageContent(message, isStreaming, partialContent, status)}
            
            {(timestamp || status !== 'sent') && (
              <div className="text-xs opacity-80 mt-1 text-right flex items-center justify-end gap-1">
                {status !== 'sent' && (
                  <span className={cn(
                    "inline-block text-xs font-medium",
                    status === 'delivered' ? "text-green-500" : 
                    status === 'failed' ? "text-red-500" : "text-gray-400"
                  )}>
                    {status === 'delivered' ? '✓' : 
                     status === 'failed' ? '✕' : '⋯'}
                  </span>
                )}
                {timestamp && formatTimestamp(timestamp)}
              </div>
            )}
            
            {isHighRisk && (
              <div className="absolute top-0 right-0 transform translate-x-1/3 -translate-y-1/3">
                <span className="inline-flex items-center justify-center w-5 h-5 bg-destructive text-destructive-foreground text-xs rounded-full">
                  !
                </span>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="flex justify-start">
          <div
            className={cn(
              status === 'cancelled' 
                ? `bg-secondary/80 dark:bg-secondary/30 text-foreground dark:text-foreground shadow-sm border-l-2 border-amber-500 ${bubbleRounding} px-4 ${yPadding} max-w-[85%] md:max-w-[80%] text-body relative transition-all duration-200 ${animationClass}`
                : `bg-secondary/80 dark:bg-secondary/30 text-foreground dark:text-foreground shadow-sm ${bubbleRounding} px-4 ${yPadding} max-w-[85%] md:max-w-[80%] text-body relative transition-all duration-200 ${animationClass}`,
              isStreaming && status !== 'delivered' ? 'bubble--streaming' : '',
              className
            )}
            data-bubble-status={bubbleStatus}
          >
            <p className="font-medium mb-2 text-foreground dark:text-foreground/90 flex items-center">
              {isError && status !== 'delivered' ? (
                <>
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1.5 text-destructive">
                    <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
                    <line x1="12" y1="9" x2="12" y2="13"/>
                    <line x1="12" y1="17" x2="12.01" y2="17"/>
                  </svg>
                  System Message
                </>
              ) : (
                <>
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1.5 text-primary">
                    <path d="M20 11.08V8l-6-6H6a2 2 0 0 0-2 2v16c0 1.1.9 2 2 2h6"/>
                    <path d="M14 2v6h6"/>
                    <path d="M15.97 14.41a2.22 2.22 0 0 0-3.08-1.32c-.77.34-1.3 1.12-1.3 2.02 0 1.21.89 2.18 2 2.18"/>
                    <path d="M15.97 20.41a2.22 2.22 0 0 0-3.08-1.32c-.77.34-1.3 1.12-1.3 2.02 0 1.21.89 2.18 2 2.18"/>
                    <path d="M6 10h4"/>
                    <path d="M6 14h1"/>
                    <circle cx="20" cy="16" r="6"/>
                  </svg>
                  Medical AI Assistant
                </>
              )}
            </p>
            
            {showHighRiskAlert && (
              <div className="mb-3 p-3 bg-destructive/10 dark:bg-destructive/20 text-destructive dark:text-destructive-foreground border border-destructive/30 rounded-md text-sm animate-fade-in">
                <p className="flex items-start">
                  <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 text-destructive mt-0.5 flex-shrink-0">
                    <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
                    <line x1="12" y1="9" x2="12" y2="13"/>
                    <line x1="12" y1="17" x2="12.01" y2="17"/>
                  </svg>
                  <span><strong>Important Medical Notice:</strong> If this is a medical emergency, please contact emergency services immediately.</span>
                </p>
              </div>
            )}
            
            {formatMessageContent(message, isStreaming, partialContent, status)}
            
            {/* Show metadata if available in non-user messages */}
            {/* Show Stop AI button when streaming is active */}
            {!isUser && isStreaming && status !== 'delivered' && status !== 'failed' && status !== 'stopped' && onStopAI && (
              <div className="mt-2 flex justify-start">
                <button
                  onClick={onStopAI}
                  disabled={isStoppingAI}
                  className="flex items-center text-xs py-1 px-2.5 rounded-md bg-destructive/20 hover:bg-destructive/30 text-destructive font-medium transition-colors"
                  title="Stop the AI response"
                  aria-label="Stop AI response"
                >
                  {isStoppingAI ? (
                    <span className="flex items-center">
                      <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1 animate-spin">
                        <circle cx="12" cy="12" r="10"></circle>
                        <path d="M12 6v6l4 2"></path>
                      </svg>
                      Stopping...
                    </span>
                  ) : (
                    <span className="flex items-center">
                      <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                        <rect x="6" y="6" width="12" height="12"></rect>
                      </svg>
                      Stop AI
                    </span>
                  )}
                </button>
              </div>
            )}
            
            {/* Show response metadata for completed non-error messages */}
            {!isUser && metadata && metadata.requestTime && !isError && !isStreaming && (
              <div className="text-xs text-muted-foreground dark:text-muted-foreground/80 mt-2 flex items-center gap-1.5">
                <span className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                    <circle cx="12" cy="12" r="10"/>
                    <polyline points="12 6 12 12 16 14"/>
                  </svg>
                  Response time: {Math.round(metadata.requestTime/100)/10}s
                  {status === 'stopped' && ' (stopped)'}
                </span>
                {metadata.attemptCount > 1 && (
                  <span className="ml-1 opacity-80">(after {metadata.attemptCount} attempts)</span>
                )}
              </div>
            )}
            
            {(timestamp || status !== 'sent') && (
              <div className="text-xs text-muted-foreground dark:text-muted-foreground/80 mt-2 flex items-center gap-1.5 opacity-80">
                {timestamp && formatTimestamp(timestamp)}
                {status !== 'sent' && (
                  <span className={cn(
                    "inline-flex items-center text-xs font-medium",
                    status === 'delivered' ? "text-success dark:text-success/90" : 
                    status === 'failed' ? "text-destructive dark:text-destructive/90" : "text-muted-foreground"
                  )}>
                    {status === 'delivered' ? (
                      <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-0.5">
                        <path d="M20 6L9 17l-5-5"/>
                      </svg>
                    ) : status === 'failed' ? (
                      <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-0.5">
                        <line x1="18" y1="6" x2="6" y2="18"/>
                        <line x1="6" y1="6" x2="18" y2="18"/>
                      </svg>
                    ) : (
                      <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-0.5 animate-spin">
                        <path d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                      </svg>
                    )}
                    {status}
                  </span>
                )}
              </div>
            )}
            
            {/* Show cancelled message notice */}
            {!isUser && status === 'cancelled' && (
              <div className="mt-3 text-xs text-muted-foreground dark:text-muted-foreground/80 flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1.5">
                  <rect x="6" y="6" width="12" height="12"></rect>
                </svg>
                Response cancelled by user
              </div>
            )}
            
            {/* Show retry button for errors but not for cancelled messages */}
            {isError && status !== 'cancelled' && (
              <div className="mt-3 text-sm">
                <button 
                  className="flex items-center text-primary hover:text-primary-900 dark:hover:text-primary-500 transition-colors duration-200 px-3 py-1.5 rounded-md bg-primary/5 hover:bg-primary/10 dark:bg-primary/10 dark:hover:bg-primary/20 focus:outline-none focus:ring-2 focus:ring-primary/20"
                  onClick={() => onRetry && onRetry(originalMessage)}
                  aria-label="Try sending the message again"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1.5">
                    <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/>
                    <path d="M21 3v5h-5"/>
                    <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/>
                    <path d="M8 16H3v5"/>
                  </svg>
                  Try again
                </button>
              </div>
            )}
            
            {/* Follow-up suggestions */}
            {!isUser && !isError && isLast && showFollowUps && (
              <div className="mt-4 pt-3 border-t border-border dark:border-border/70 animate-fade-in">
                <p className="text-xs font-medium text-foreground/70 dark:text-foreground/60 mb-2.5 flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1.5">
                    <polyline points="15 14 20 9 15 4"/>
                    <path d="M4 20v-7a4 4 0 0 1 4-4h12"/>
                  </svg>
                  Suggested follow-up questions:
                </p>
                <div className="flex flex-wrap gap-2">
                  {getFollowUpSuggestions().map((suggestion, index) => (
                    <button
                      key={index}
                      onClick={() => onFollowUpClick && onFollowUpClick(suggestion)}
                      className="px-3 py-2 bg-blue-100 hover:bg-blue-200 text-blue-800 dark:bg-blue-800 dark:hover:bg-blue-700 dark:text-white text-sm rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-primary/30 shadow-sm"
                      aria-label={`Ask follow-up question: ${suggestion}`}
                    >
                      {suggestion}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}