import React from 'react';
import { useEffect } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '../hooks/useAuth';

/**
 * Props for the ProtectedRoute component
 * @typedef {object} ProtectedRouteProps
 * @property {import('react').ReactNode} children - Child components to render if authenticated
 */

/**
 * LoadingSpinner component to display during authentication check
 * @returns {JSX.Element} The loading spinner
 */
export function LoadingSpinner() {
  return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
    </div>
  );
}

/**
 * ProtectedRoute component that restricts access to authenticated users only
 * Redirects to login if not authenticated, shows loading spinner during auth check
 * 
 * @param {object} props - Component props
 * @param {import('react').ReactNode} props.children - Child components to render if authenticated
 * @returns {JSX.Element|null} The rendered component or null during redirect
 */
export function ProtectedRoute({ children }) {
  const { isAuthenticated, isLoading } = useAuth();
  const [, setLocation] = useLocation();
  
  useEffect(() => {
    // Only redirect when loading is complete and user is not authenticated
    if (!isLoading && !isAuthenticated) {
      setLocation('/login');
    }
  }, [isAuthenticated, isLoading, setLocation]);

  // Show loading spinner while checking authentication
  if (isLoading) {
    return <LoadingSpinner />;
  }
  
  // Render children only if authenticated
  return isAuthenticated ? <>{children}</> : null;
}