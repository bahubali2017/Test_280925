import * as React from "react"
import * as AlertDialogPrimitive from "@radix-ui/react-alert-dialog"

import { cn } from "@/lib/utils"
import { buttonVariants } from "@/components/ui/button"

/**
 * Alert dialog root component
 */
const AlertDialog = AlertDialogPrimitive.Root

/**
 * Alert dialog trigger component
 */
const AlertDialogTrigger = AlertDialogPrimitive.Trigger

/**
 * Alert dialog portal component
 */
const AlertDialogPortal = AlertDialogPrimitive.Portal

/**
 * Alert dialog overlay component
 * @param {object} props - Component props
 * @param {string} [props.className] - Additional class names
 * @param {React.Ref<React.ElementRef<typeof AlertDialogPrimitive.Overlay>>} ref - Forwarded ref
 * @returns {JSX.Element} Alert dialog overlay component
 */
const AlertDialogOverlay = React.forwardRef(
  ({ className, ...props }, ref) => (
    <AlertDialogPrimitive.Overlay
      className={cn(
        "fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
        className
      )}
      {...props}
      ref={ref}
    />
  )
)
AlertDialogOverlay.displayName = AlertDialogPrimitive.Overlay.displayName

/**
 * Alert dialog content component
 * @param {object} props - Component props
 * @param {string} [props.className] - Additional class names
 * @param {React.Ref<React.ElementRef<typeof AlertDialogPrimitive.Content>>} ref - Forwarded ref
 * @returns {JSX.Element} Alert dialog content component
 */
const AlertDialogContent = React.forwardRef(
  ({ className, ...props }, ref) => (
    <AlertDialogPortal>
      <AlertDialogOverlay />
      <AlertDialogPrimitive.Content
        ref={ref}
        className={cn(
          "fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-left-1/2 data-[state=closed]:slide-out-to-top-[48%] data-[state=open]:slide-in-from-left-1/2 data-[state=open]:slide-in-from-top-[48%] sm:rounded-lg",
          className
        )}
        {...props}
      />
    </AlertDialogPortal>
  )
)
AlertDialogContent.displayName = AlertDialogPrimitive.Content.displayName

/**
 * Alert dialog header component
 * @param {object} props - Component props
 * @param {string} [props.className] - Additional class names
 * @returns {JSX.Element} Alert dialog header component
 */
const AlertDialogHeader = ({
  className,
  ...props
}) => (
  <div
    className={cn(
      "flex flex-col space-y-2 text-center sm:text-left",
      className
    )}
    {...props}
  />
)
AlertDialogHeader.displayName = "AlertDialogHeader"

/**
 * Alert dialog footer component
 * @param {object} props - Component props
 * @param {string} [props.className] - Additional class names
 * @returns {JSX.Element} Alert dialog footer component
 */
const AlertDialogFooter = ({
  className,
  ...props
}) => (
  <div
    className={cn(
      "flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2",
      className
    )}
    {...props}
  />
)
AlertDialogFooter.displayName = "AlertDialogFooter"

/**
 * Alert dialog title component
 * @param {object} props - Component props
 * @param {string} [props.className] - Additional class names
 * @param {React.Ref<React.ElementRef<typeof AlertDialogPrimitive.Title>>} ref - Forwarded ref
 * @returns {JSX.Element} Alert dialog title component
 */
const AlertDialogTitle = React.forwardRef(
  ({ className, ...props }, ref) => (
    <AlertDialogPrimitive.Title
      ref={ref}
      className={cn("text-lg font-semibold", className)}
      {...props}
    />
  )
)
AlertDialogTitle.displayName = AlertDialogPrimitive.Title.displayName

/**
 * Alert dialog description component
 * @param {object} props - Component props
 * @param {string} [props.className] - Additional class names
 * @param {React.Ref<React.ElementRef<typeof AlertDialogPrimitive.Description>>} ref - Forwarded ref
 * @returns {JSX.Element} Alert dialog description component
 */
const AlertDialogDescription = React.forwardRef(
  ({ className, ...props }, ref) => (
    <AlertDialogPrimitive.Description
      ref={ref}
      className={cn("text-sm text-muted-foreground", className)}
      {...props}
    />
  )
)
AlertDialogDescription.displayName =
  AlertDialogPrimitive.Description.displayName

/**
 * Alert dialog action component
 * @param {object} props - Component props
 * @param {string} [props.className] - Additional class names
 * @param {React.Ref<React.ElementRef<typeof AlertDialogPrimitive.Action>>} ref - Forwarded ref
 * @returns {JSX.Element} Alert dialog action component
 */
const AlertDialogAction = React.forwardRef(
  ({ className, ...props }, ref) => (
    <AlertDialogPrimitive.Action
      ref={ref}
      className={cn(buttonVariants(), className)}
      {...props}
    />
  )
)
AlertDialogAction.displayName = AlertDialogPrimitive.Action.displayName

/**
 * Alert dialog cancel component
 * @param {object} props - Component props
 * @param {string} [props.className] - Additional class names
 * @param {React.Ref<React.ElementRef<typeof AlertDialogPrimitive.Cancel>>} ref - Forwarded ref
 * @returns {JSX.Element} Alert dialog cancel component
 */
const AlertDialogCancel = React.forwardRef(
  ({ className, ...props }, ref) => (
    <AlertDialogPrimitive.Cancel
      ref={ref}
      className={cn(
        buttonVariants({ variant: "outline" }),
        "mt-2 sm:mt-0",
        className
      )}
      {...props}
    />
  )
)
AlertDialogCancel.displayName = AlertDialogPrimitive.Cancel.displayName

/**
 * Export all Alert Dialog components for use in other files
 * @module AlertDialog
 */
export {
  AlertDialog,
  AlertDialogPortal,
  AlertDialogOverlay,
  AlertDialogTrigger,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogFooter,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogAction,
  AlertDialogCancel,
}