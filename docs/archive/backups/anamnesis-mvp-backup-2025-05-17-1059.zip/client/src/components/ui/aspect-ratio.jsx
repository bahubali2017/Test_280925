import * as AspectRatioPrimitive from "@radix-ui/react-aspect-ratio"

/**
 * AspectRatio component
 * Maintains a consistent width-to-height ratio
 */
const AspectRatio = AspectRatioPrimitive.Root

/**
 *
 */
export { AspectRatio }