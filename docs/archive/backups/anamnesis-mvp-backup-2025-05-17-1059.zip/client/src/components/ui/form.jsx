"use client"

import * as React from "react"
import * as LabelPrimitive from "@radix-ui/react-label"
import { Slot } from "@radix-ui/react-slot"
import {
  Controller,
  FormProvider,
  useFormContext,
} from "react-hook-form"

import { cn } from "@/lib/utils"
import { Label } from "@/components/ui/label"

/**
 * Form provider component
 */
const Form = FormProvider

/**
 * @typedef {object} FormFieldContextValue
 * @property {string} name - Field name
 */

/**
 * Form field context
 * @type {React.Context<FormFieldContextValue>}
 */
const FormFieldContext = React.createContext({})

/**
 * Form field component
 * @param {import('react-hook-form').ControllerProps} props - Controller props
 * @returns {JSX.Element} Form field component
 */
const FormField = (props) => {
  return (
    <FormFieldContext.Provider value={{ name: props.name }}>
      <Controller {...props} />
    </FormFieldContext.Provider>
  )
}

/**
 * Custom hook for form field state
 * @returns {object} Form field state and props
 */
const useFormField = () => {
  const fieldContext = React.useContext(FormFieldContext)
  const itemContext = React.useContext(FormItemContext)
  const { getFieldState, formState } = useFormContext()

  const fieldState = getFieldState(fieldContext.name, formState)

  if (!fieldContext) {
    throw new Error("useFormField should be used within <FormField>")
  }

  const { id } = itemContext

  return {
    id,
    name: fieldContext.name,
    formItemId: `${id}-form-item`,
    formDescriptionId: `${id}-form-item-description`,
    formMessageId: `${id}-form-item-message`,
    ...fieldState,
  }
}

/**
 * @typedef {object} FormItemContextValue
 * @property {string} id - Item ID
 */

/**
 * Form item context
 * @type {React.Context<FormItemContextValue>}
 */
const FormItemContext = React.createContext({})

/**
 * Form item component
 * @param {object} props - Component props
 * @param {string} [props.className] - Additional class names
 * @param {React.Ref<HTMLDivElement>} ref - Forwarded ref
 * @returns {JSX.Element} Form item component
 */
const FormItem = React.forwardRef(
  ({ className, ...props }, ref) => {
    const id = React.useId()

    return (
      <FormItemContext.Provider value={{ id }}>
        <div ref={ref} className={cn("space-y-2", className)} {...props} />
      </FormItemContext.Provider>
    )
  }
)

FormItem.displayName = "FormItem"

/**
 * Form label component
 * @param {object} props - Component props
 * @param {string} [props.className] - Additional class names
 * @param {React.Ref<React.ElementRef<typeof LabelPrimitive.Root>>} ref - Forwarded ref
 * @returns {JSX.Element} Form label component
 */
const FormLabel = React.forwardRef(
  ({ className, ...props }, ref) => {
    const { error, formItemId } = useFormField()

    return (
      <Label
        ref={ref}
        className={cn(error && "text-destructive", className)}
        htmlFor={formItemId}
        {...props}
      />
    )
  }
)

FormLabel.displayName = "FormLabel"

/**
 * Form control component
 * @param {object} props - Component props
 * @param {React.Ref<React.ElementRef<typeof Slot>>} ref - Forwarded ref
 * @returns {JSX.Element} Form control component
 */
const FormControl = React.forwardRef(
  ({ ...props }, ref) => {
    const { error, formItemId, formDescriptionId, formMessageId } = useFormField()

    return (
      <Slot
        ref={ref}
        id={formItemId}
        aria-describedby={
          !error
            ? `${formDescriptionId}`
            : `${formDescriptionId} ${formMessageId}`
        }
        aria-invalid={!!error}
        {...props}
      />
    )
  }
)

FormControl.displayName = "FormControl"

/**
 * Form description component
 * @param {object} props - Component props
 * @param {string} [props.className] - Additional class names
 * @param {React.Ref<HTMLParagraphElement>} ref - Forwarded ref
 * @returns {JSX.Element} Form description component
 */
const FormDescription = React.forwardRef(
  ({ className, ...props }, ref) => {
    const { formDescriptionId } = useFormField()

    return (
      <p
        ref={ref}
        id={formDescriptionId}
        className={cn("text-sm text-muted-foreground", className)}
        {...props}
      />
    )
  }
)

FormDescription.displayName = "FormDescription"

/**
 * Form message component
 * @param {object} props - Component props
 * @param {string} [props.className] - Additional class names
 * @param {React.ReactNode} [props.children] - Child elements
 * @param {React.Ref<HTMLParagraphElement>} ref - Forwarded ref
 * @returns {JSX.Element|null} Form message component
 */
const FormMessage = React.forwardRef(
  ({ className, children, ...props }, ref) => {
    const { error, formMessageId } = useFormField()
    const body = error ? String(error?.message ?? "") : children

    if (!body) {
      return null
    }

    return (
      <p
        ref={ref}
        id={formMessageId}
        className={cn("text-sm font-medium text-destructive", className)}
        {...props}
      >
        {body}
      </p>
    )
  }
)

FormMessage.displayName = "FormMessage"

/**
 * Export Form components
 * @module Form
 */
export {
  useFormField,
  Form,
  FormItem,
  FormLabel,
  FormControl,
  FormDescription,
  FormMessage,
  FormField,
}