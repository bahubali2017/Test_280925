import * as React from "react"
import * as LabelPrimitive from "@radix-ui/react-label"
import { cva } from "class-variance-authority"

import { cn } from "@/lib/utils"

/**
 * Label variant styles using class-variance-authority
 * @type {import('class-variance-authority').VariantProps<typeof labelVariants>}
 */
const labelVariants = cva(
  "text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
)

/**
 * Label component
 * @param {object} props - Component props
 * @param {string} [props.className] - Additional class names
 * @param {React.Ref<React.ElementRef<typeof LabelPrimitive.Root>>} ref - Forwarded ref
 * @returns {JSX.Element} Label component
 */
const Label = React.forwardRef(
  ({ className, ...props }, ref) => (
    <LabelPrimitive.Root
      ref={ref}
      className={cn(labelVariants(), className)}
      {...props}
    />
  )
)

Label.displayName = LabelPrimitive.Root.displayName

/**
 * Export Label component
 * @module Label
 */
export { Label }