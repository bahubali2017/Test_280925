"use client"

import * as React from "react"
import * as MenubarPrimitive from "@radix-ui/react-menubar"
import { Check, ChevronRight, Circle } from "lucide-react"

import { cn } from "@/lib/utils"

/**
 * Menubar menu component
 * @param {object} props - Component props
 * @returns {JSX.Element} Menubar menu component
 */
function MenubarMenu({ ...props }) {
  return <MenubarPrimitive.Menu {...props} />
}

/**
 * Menubar group component
 * @param {object} props - Component props
 * @returns {JSX.Element} Menubar group component
 */
function MenubarGroup({ ...props }) {
  return <MenubarPrimitive.Group {...props} />
}

/**
 * Menubar portal component
 * @param {object} props - Component props
 * @returns {JSX.Element} Menubar portal component
 */
function MenubarPortal({ ...props }) {
  return <MenubarPrimitive.Portal {...props} />
}

/**
 * Menubar radio group component
 * @param {object} props - Component props
 * @returns {JSX.Element} Menubar radio group component
 */
function MenubarRadioGroup({ ...props }) {
  return <MenubarPrimitive.RadioGroup {...props} />
}

/**
 * Menubar sub component
 * @param {object} props - Component props
 * @returns {JSX.Element} Menubar sub component
 */
function MenubarSub({ ...props }) {
  return <MenubarPrimitive.Sub data-slot="menubar-sub" {...props} />
}

/**
 * Menubar root component
 * @param {object} props - Component props
 * @param {string} [props.className] - Additional class names
 * @param {React.Ref<HTMLDivElement>} ref - Forwarded ref
 * @returns {JSX.Element} Menubar root component
 */
const Menubar = React.forwardRef(
  ({ className, ...props }, ref) => (
    <MenubarPrimitive.Root
      ref={ref}
      className={cn(
        "flex h-10 items-center space-x-1 rounded-md border bg-background p-1",
        className
      )}
      {...props}
    />
  )
)
Menubar.displayName = MenubarPrimitive.Root.displayName

/**
 * Menubar trigger component
 * @param {object} props - Component props
 * @param {string} [props.className] - Additional class names
 * @param {React.Ref<HTMLButtonElement>} ref - Forwarded ref
 * @returns {JSX.Element} Menubar trigger component
 */
const MenubarTrigger = React.forwardRef(
  ({ className, ...props }, ref) => (
    <MenubarPrimitive.Trigger
      ref={ref}
      className={cn(
        "flex cursor-default select-none items-center rounded-sm px-3 py-1.5 text-sm font-medium outline-none focus:bg-accent focus:text-accent-foreground data-[state=open]:bg-accent data-[state=open]:text-accent-foreground",
        className
      )}
      {...props}
    />
  )
)
MenubarTrigger.displayName = MenubarPrimitive.Trigger.displayName

/**
 * Menubar sub trigger component
 * @param {object} props - Component props
 * @param {string} [props.className] - Additional class names
 * @param {boolean} [props.inset] - Whether to inset the content
 * @param {React.ReactNode} props.children - Child elements
 * @param {React.Ref<HTMLDivElement>} ref - Forwarded ref
 * @returns {JSX.Element} Menubar sub trigger component
 */
const MenubarSubTrigger = React.forwardRef(
  ({ className, inset, children, ...props }, ref) => (
    <MenubarPrimitive.SubTrigger
      ref={ref}
      className={cn(
        "flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[state=open]:bg-accent data-[state=open]:text-accent-foreground",
        inset && "pl-8",
        className
      )}
      {...props}
    >
      {children}
      <ChevronRight className="ml-auto h-4 w-4" />
    </MenubarPrimitive.SubTrigger>
  )
)
MenubarSubTrigger.displayName = MenubarPrimitive.SubTrigger.displayName

/**
 * Menubar sub content component
 * @param {object} props - Component props
 * @param {string} [props.className] - Additional class names
 * @param {React.Ref<HTMLDivElement>} ref - Forwarded ref
 * @returns {JSX.Element} Menubar sub content component
 */
const MenubarSubContent = React.forwardRef(
  ({ className, ...props }, ref) => (
    <MenubarPrimitive.SubContent
      ref={ref}
      className={cn(
        "z-50 min-w-[8rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-[--radix-menubar-content-transform-origin]",
        className
      )}
      {...props}
    />
  )
)
MenubarSubContent.displayName = MenubarPrimitive.SubContent.displayName

/**
 * Menubar content component
 * @param {object} props - Component props
 * @param {string} [props.className] - Additional class names
 * @param {'start'|'center'|'end'} [props.align='start'] - Alignment of the content
 * @param {number} [props.alignOffset=-4] - Alignment offset
 * @param {number} [props.sideOffset=8] - Side offset
 * @param {React.Ref<HTMLDivElement>} ref - Forwarded ref
 * @returns {JSX.Element} Menubar content component
 */
const MenubarContent = React.forwardRef(
  (
    { className, align = "start", alignOffset = -4, sideOffset = 8, ...props },
    ref
  ) => (
    <MenubarPrimitive.Portal>
      <MenubarPrimitive.Content
        ref={ref}
        align={align}
        alignOffset={alignOffset}
        sideOffset={sideOffset}
        className={cn(
          "z-50 min-w-[12rem] overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-md data-[state=open]:animate-in data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-[--radix-menubar-content-transform-origin]",
          className
        )}
        {...props}
      />
    </MenubarPrimitive.Portal>
  )
)
MenubarContent.displayName = MenubarPrimitive.Content.displayName

/**
 * Menubar item component
 * @param {object} props - Component props
 * @param {string} [props.className] - Additional class names
 * @param {boolean} [props.inset] - Whether to inset the content
 * @param {React.Ref<HTMLDivElement>} ref - Forwarded ref
 * @returns {JSX.Element} Menubar item component
 */
const MenubarItem = React.forwardRef(
  ({ className, inset, ...props }, ref) => (
    <MenubarPrimitive.Item
      ref={ref}
      className={cn(
        "relative flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
        inset && "pl-8",
        className
      )}
      {...props}
    />
  )
)
MenubarItem.displayName = MenubarPrimitive.Item.displayName

/**
 * Menubar checkbox item component
 * @param {object} props - Component props
 * @param {string} [props.className] - Additional class names
 * @param {React.ReactNode} props.children - Child elements
 * @param {boolean} [props.checked] - Whether the checkbox is checked
 * @param {React.Ref<HTMLDivElement>} ref - Forwarded ref
 * @returns {JSX.Element} Menubar checkbox item component
 */
const MenubarCheckboxItem = React.forwardRef(
  ({ className, children, checked, ...props }, ref) => (
    <MenubarPrimitive.CheckboxItem
      ref={ref}
      className={cn(
        "relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
        className
      )}
      checked={checked}
      {...props}
    >
      <span className="absolute left-2 flex h-3.5 w-3.5 items-center justify-center">
        <MenubarPrimitive.ItemIndicator>
          <Check className="h-4 w-4" />
        </MenubarPrimitive.ItemIndicator>
      </span>
      {children}
    </MenubarPrimitive.CheckboxItem>
  )
)
MenubarCheckboxItem.displayName = MenubarPrimitive.CheckboxItem.displayName

/**
 * Menubar radio item component
 * @param {object} props - Component props
 * @param {string} [props.className] - Additional class names
 * @param {React.ReactNode} props.children - Child elements
 * @param {React.Ref<HTMLDivElement>} ref - Forwarded ref
 * @returns {JSX.Element} Menubar radio item component
 */
const MenubarRadioItem = React.forwardRef(
  ({ className, children, ...props }, ref) => (
    <MenubarPrimitive.RadioItem
      ref={ref}
      className={cn(
        "relative flex cursor-default select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
        className
      )}
      {...props}
    >
      <span className="absolute left-2 flex h-3.5 w-3.5 items-center justify-center">
        <MenubarPrimitive.ItemIndicator>
          <Circle className="h-2 w-2 fill-current" />
        </MenubarPrimitive.ItemIndicator>
      </span>
      {children}
    </MenubarPrimitive.RadioItem>
  )
)
MenubarRadioItem.displayName = MenubarPrimitive.RadioItem.displayName

/**
 * Menubar label component
 * @param {object} props - Component props
 * @param {string} [props.className] - Additional class names
 * @param {boolean} [props.inset] - Whether to inset the content
 * @param {React.Ref<HTMLDivElement>} ref - Forwarded ref
 * @returns {JSX.Element} Menubar label component
 */
const MenubarLabel = React.forwardRef(
  ({ className, inset, ...props }, ref) => (
    <MenubarPrimitive.Label
      ref={ref}
      className={cn(
        "px-2 py-1.5 text-sm font-semibold",
        inset && "pl-8",
        className
      )}
      {...props}
    />
  )
)
MenubarLabel.displayName = MenubarPrimitive.Label.displayName

/**
 * Menubar separator component
 * @param {object} props - Component props
 * @param {string} [props.className] - Additional class names
 * @param {React.Ref<HTMLDivElement>} ref - Forwarded ref
 * @returns {JSX.Element} Menubar separator component
 */
const MenubarSeparator = React.forwardRef(
  ({ className, ...props }, ref) => (
    <MenubarPrimitive.Separator
      ref={ref}
      className={cn("-mx-1 my-1 h-px bg-muted", className)}
      {...props}
    />
  )
)
MenubarSeparator.displayName = MenubarPrimitive.Separator.displayName

/**
 * Menubar shortcut component for displaying keyboard shortcuts
 * @param {object} props - Component props
 * @param {string} [props.className] - Additional class names
 * @returns {JSX.Element} Menubar shortcut component
 */
const MenubarShortcut = ({
  className,
  ...props
}) => {
  return (
    <span
      className={cn(
        "ml-auto text-xs tracking-widest text-muted-foreground",
        className
      )}
      {...props}
    />
  )
}
MenubarShortcut.displayname = "MenubarShortcut"

/**
 * Export Menubar components
 * @module Menubar
 */
export {
  Menubar,
  MenubarMenu,
  MenubarTrigger,
  MenubarContent,
  MenubarItem,
  MenubarSeparator,
  MenubarLabel,
  MenubarCheckboxItem,
  MenubarRadioGroup,
  MenubarRadioItem,
  MenubarPortal,
  MenubarSubContent,
  MenubarSubTrigger,
  MenubarGroup,
  MenubarSub,
  MenubarShortcut,
}