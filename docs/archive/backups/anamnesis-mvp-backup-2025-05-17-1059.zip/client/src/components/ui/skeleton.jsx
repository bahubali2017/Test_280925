import { cn } from "@/lib/utils"

/**
 * Skeleton component for loading states
 * @param {object} props - Component props
 * @param {string} [props.className] - Additional class names
 * @returns {JSX.Element} Skeleton component
 */
function Skeleton({
  className,
  ...props
}) {
  return (
    <div
      className={cn("animate-pulse rounded-md bg-muted", className)}
      {...props}
    />
  )
}

/**
 * Export Skeleton component
 * @module Skeleton
 */
export { Skeleton }