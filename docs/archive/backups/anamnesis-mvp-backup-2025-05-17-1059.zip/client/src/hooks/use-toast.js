/**
 * @file Toast notification hook for the Anamnesis Medical AI Assistant
 * Provides a simple toast notification system
 */

import { useState, useCallback, useEffect } from 'react';

/**
 * @typedef {object} ToastOptions
 * @property {string} title - The toast title
 * @property {string} [description] - Optional toast description
 * @property {string} [variant='default'] - Toast variant (default, success, error, warning)
 * @property {number} [duration=3000] - Duration in milliseconds 
 */

/**
 * @typedef {object} Toast
 * @property {string} id - Unique ID for the toast
 * @property {string} title - Toast title
 * @property {string} [description] - Toast description if provided
 * @property {string} variant - Toast variant
 */

/**
 * @typedef {object} UseToastReturn
 * @property {Function} toast - Function to show a toast
 * @property {Function} dismiss - Function to dismiss a specific toast
 * @property {Function} dismissAll - Function to dismiss all toasts
 * @property {Toast[]} toasts - Array of active toasts
 */

/**
 * Simple toast notification hook
 * @returns {UseToastReturn} Toast functions and state
 */
export function useToast() {
  const [toasts, setToasts] = useState([]);

  /**
   * Generate a unique ID for toasts
   * @returns {string} Unique ID
   */
  const generateId = useCallback(() => {
    return Math.random().toString(36).slice(2, 11);
  }, []);

  /**
   * Show a toast notification
   * @param {ToastOptions} options - Toast options
   * @returns {string} Toast ID
   */
  const toast = useCallback((options) => {
    const id = generateId();
    const { title, description = '', variant = 'default', duration = 3000 } = options;
    
    const newToast = {
      id,
      title,
      description,
      variant,
    };
    
    setToasts((prev) => [...prev, newToast]);
    
    // Auto-dismiss after duration
    if (duration > 0) {
      window.setTimeout(() => {
        dismiss(id);
      }, duration);
    }
    
    return id;
  }, [generateId]);

  /**
   * Dismiss a specific toast
   * @param {string} id - Toast ID to dismiss
   */
  const dismiss = useCallback((id) => {
    setToasts((prev) => prev.filter((toast) => toast.id !== id));
  }, []);

  /**
   * Dismiss all toasts
   */
  const dismissAll = useCallback(() => {
    setToasts([]);
  }, []);

  // Clean up any remaining toasts on unmount
  useEffect(() => {
    return () => {
      setToasts([]);
    };
  }, []);

  return {
    toast,
    dismiss,
    dismissAll,
    toasts
  };
}

/**
 * Default export of the useToast hook
 * @module useToast
 */
export default useToast;