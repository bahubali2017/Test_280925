import * as React from "react"

// Constants
const TOAST_LIMIT = 1
const TOAST_REMOVE_DELAY = 1000000

/**
 * @typedef {import('@/components/ui/toast').ToastProps & {
 *   id: string,
 *   title?: React.ReactNode,
 *   description?: React.ReactNode,
 *   action?: import('@/components/ui/toast').ToastActionElement
 * }} ToasterToast
 */

let count = 0

/**
 * Generates a unique ID for each toast
 * @returns {string} A unique toast ID
 */
function genId() {
  count = (count + 1) % Number.MAX_SAFE_INTEGER
  return count.toString()
}

/**
 * @typedef {object} State
 * @property {ToasterToast[]} toasts - Array of toast notifications
 */

/**
 * @typedef {object} AddToastAction
 * @property {string} type - Action type
 * @property {ToasterToast} toast - Toast to add
 */

/**
 * @typedef {object} UpdateToastAction
 * @property {string} type - Action type
 * @property {Partial<ToasterToast>} toast - Toast updates
 */

/**
 * @typedef {object} DismissToastAction
 * @property {string} type - Action type
 * @property {string} [toastId] - ID of toast to dismiss
 */

/**
 * @typedef {object} RemoveToastAction
 * @property {string} type - Action type
 * @property {string} [toastId] - ID of toast to remove
 */

/**
 * @typedef {AddToastAction | UpdateToastAction | DismissToastAction | RemoveToastAction} Action
 */

/**
 * Map to store timeouts for toast removal
 * @type {Map<string, ReturnType<typeof globalThis.setTimeout>>}
 */
const toastTimeouts = new Map()

/**
 * Adds a toast to the removal queue
 * @param {string} toastId - ID of the toast to remove
 * @returns {void}
 */
const addToRemoveQueue = (toastId) => {
  if (toastTimeouts.has(toastId)) {
    return
  }

  const timeout = globalThis.setTimeout(() => {
    toastTimeouts.delete(toastId)
    dispatch({
      type: "REMOVE_TOAST",
      toastId: toastId,
    })
  }, TOAST_REMOVE_DELAY)

  toastTimeouts.set(toastId, timeout)
}

/**
 * Reducer function for toast state management
 * @param {State} state - Current state
 * @param {Action} action - Action to perform
 * @returns {State} New state
 */
export const reducer = (state, action) => {
  switch (action.type) {
    case "ADD_TOAST":
      return {
        ...state,
        toasts: [action.toast, ...state.toasts].slice(0, TOAST_LIMIT),
      }

    case "UPDATE_TOAST":
      return {
        ...state,
        toasts: state.toasts.map((t) =>
          t.id === action.toast.id ? { ...t, ...action.toast } : t
        ),
      }

    case "DISMISS_TOAST": {
      const { toastId } = action

      // ! Side effects ! - This could be extracted into a dismissToast() action,
      // but I'll keep it here for simplicity
      if (toastId) {
        addToRemoveQueue(toastId)
      } else {
        state.toasts.forEach((toast) => {
          addToRemoveQueue(toast.id)
        })
      }

      return {
        ...state,
        toasts: state.toasts.map((t) =>
          t.id === toastId || toastId === undefined
            ? {
                ...t,
                open: false,
              }
            : t
        ),
      }
    }
    case "REMOVE_TOAST":
      if (action.toastId === undefined) {
        return {
          ...state,
          toasts: [],
        }
      }
      return {
        ...state,
        toasts: state.toasts.filter((t) => t.id !== action.toastId),
      }
    default:
      return state
  }
}

/**
 * Listeners for state changes
 * @type {Array<(state: State) => void>}
 */
const listeners = []

/**
 * In-memory state storage
 * @type {State}
 */
let memoryState = { toasts: [] }

/**
 * Dispatches an action to update state
 * @param {Action} action - Action to dispatch
 * @returns {void}
 */
function dispatch(action) {
  memoryState = reducer(memoryState, action)
  listeners.forEach((listener) => {
    listener(memoryState)
  })
}

/**
 * @typedef {Omit<ToasterToast, "id">} Toast
 */

/**
 * Creates a new toast notification
 * @param {Toast} props - Toast properties
 * @returns {{id: string, dismiss: () => void, update: (props: ToasterToast) => void}} Toast control functions
 */
function toast({ ...props }) {
  const id = genId()

  /**
   * Updates a toast's properties
   * @param {ToasterToast} props - New toast properties
   * @returns {void}
   */
  const update = (props) =>
    dispatch({
      type: "UPDATE_TOAST",
      toast: { ...props, id },
    })
    
  /**
   * Dismisses the toast
   * @returns {void}
   */
  const dismiss = () => dispatch({ type: "DISMISS_TOAST", toastId: id })

  dispatch({
    type: "ADD_TOAST",
    toast: {
      ...props,
      id,
      open: true,
      onOpenChange: (open) => {
        if (!open) dismiss()
      },
    },
  })

  return {
    id: id,
    dismiss,
    update,
  }
}

/**
 * Custom hook for toast notifications
 * @returns {{toasts: ToasterToast[], toast: typeof toast, dismiss: (toastId?: string) => void}} Toast state and control functions
 */
function useToast() {
  const [state, setState] = React.useState(memoryState)

  React.useEffect(() => {
    listeners.push(setState)
    return () => {
      const index = listeners.indexOf(setState)
      if (index > -1) {
        listeners.splice(index, 1)
      }
    }
  }, [state])

  return {
    ...state,
    toast,
    dismiss: (toastId) => dispatch({ type: "DISMISS_TOAST", toastId }),
  }
}

/**
 * Export the toast functions and hook
 */
export { useToast, toast }