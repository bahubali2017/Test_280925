/**
 * @file Authentication hook for the Anamnesis Medical AI Assistant
 * Provides a simplified interface for authentication operations
 */

import React, {
  createContext,
  useContext,
  useEffect,
  useState,
  useMemo
} from 'react';
import { 
  supabaseClient, 
  signIn as supabaseSignIn,
  signUp as supabaseSignUp,
  signOut as supabaseSignOut
} from '../lib/supabase.js';

/**
 * @typedef {object} AuthContextType
 * @property {object|null} user - The authenticated user or null if not logged in
 * @property {boolean} isAuthenticated - Whether a user is authenticated
 * @property {boolean} isLoading - Whether auth state is being loaded
 * @property {(email: string, password: string) => Promise<{success: boolean, error: string|null}>} login - Login function
 * @property {(email: string, password: string, metadata?: object) => Promise<{success: boolean, error: string|null, confirmEmail?: boolean}>} register - Register function
 * @property {() => Promise<void>} logout - Logout function
 */

/**
 * Default authentication context value
 * @type {AuthContextType}
 */
const defaultAuthContext = {
  user: null,
  isAuthenticated: false,
  isLoading: true,
  login: async () => ({ success: false, error: 'Context not initialized' }),
  register: async () => ({ success: false, error: 'Context not initialized' }),
  logout: async () => {}
};

/**
 * Auth context with default values
 * @type {React.Context<AuthContextType>}
 */
export const AuthContext = createContext(defaultAuthContext);

/**
 * AuthProvider component
 * @param {{ children: React.ReactNode }} props
 * @returns {JSX.Element}
 */
export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [authListener, setAuthListener] = useState(null);

  // Initialize auth state
  useEffect(() => {
    let isMounted = true;
    
    const initAuth = async () => {
      try {
        // First check if we have an active session
        const { data: { session } } = await supabaseClient.auth.getSession();
        
        // Set the user from existing session if available
        if (session?.user && isMounted) {
          setUser(session.user);
        }
        
        // Subscribe to auth changes 
        // (only create one listener throughout the app lifecycle)
        if (!authListener && isMounted) {
          const { data } = supabaseClient.auth.onAuthStateChange(
            (_event, session) => {
              if (isMounted) {
                setUser(session?.user ?? null);
              }
            }
          );
          setAuthListener(data);
        }
      } catch (err) {
        console.error('Error initializing auth:', err);
      } finally {
        if (isMounted) {
          setIsLoading(false);
        }
      }
    };
    
    initAuth();
    
    // Clean up function
    return () => {
      isMounted = false;
      // Clean up auth listener subscription on component unmount
      if (authListener?.subscription) {
        authListener.subscription.unsubscribe();
      }
    };
  }, [authListener]);  // Only run once and when authListener changes

  /**
   * Log in with email and password
   * @param {string} email - User's email
   * @param {string} password - User's password
   * @returns {Promise<{success: boolean, error: string|null}>} Login result
   */
  async function login(email, password) {
    try {
      // For demo/testing purposes only - remove in production
      if (email === 'demo@example.com' && password === 'password') {
        const demoUser = { 
          email, 
          id: 'demo-123', 
          user_metadata: { name: 'Demo User' } 
        };
        setUser(demoUser);
        return { success: true, error: null };
      }

      const { error } = await supabaseSignIn(email, password);
      
      if (error) {
        return { success: false, error: error.message };
      }
      
      return { success: true, error: null };
    } catch (err) {
      console.error('Login error:', err);
      return { 
        success: false, 
        error: err instanceof Error ? err.message : 'Unknown login error' 
      };
    }
  }

  /**
   * Register a new user with email and password
   * @param {string} email - User's email
   * @param {string} password - User's password
   * @param {object} [metadata={}] - Additional user metadata
   * @returns {Promise<{success: boolean, error: string|null, confirmEmail?: boolean}>} Registration result
   */
  async function register(email, password, metadata = {}) {
    try {
      const { data, error } = await supabaseSignUp(email, password, metadata);
      
      if (error) {
        return { success: false, error: error.message };
      }
      
      // Check if email confirmation is required
      if (data?.user?.identities?.length === 0) {
        return { 
          success: true, 
          error: null,
          confirmEmail: true 
        };
      }
      
      return { success: true, error: null };
    } catch (err) {
      console.error('Registration error:', err);
      return { 
        success: false, 
        error: err instanceof Error ? err.message : 'Unknown registration error' 
      };
    }
  }

  /**
   * Logout the current user
   * @returns {Promise<void>}
   */
  async function logout() {
    try {
      await supabaseSignOut();
      setUser(null);
    } catch (err) {
      console.error('Logout error:', err);
    }
  }

  // Memoize the context value to prevent unnecessary re-renders
  const contextValue = useMemo(() => ({
    user, 
    isAuthenticated: !!user, 
    isLoading,
    login, 
    register,
    logout 
  }), [user, isLoading]);

  return (
    <AuthContext.Provider value={contextValue}>
      {children}
    </AuthContext.Provider>
  );
}

/**
 * Custom hook for accessing the AuthContext
 * @returns {AuthContextType}
 */
export function useAuth() {
  return useContext(AuthContext);
}
