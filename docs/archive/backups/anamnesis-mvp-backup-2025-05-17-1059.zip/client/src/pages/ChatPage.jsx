import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '../hooks/useAuth';
import { Button } from '../components/Button';
import { MessageBubble } from '../components/MessageBubble';
import { Input } from '../components/Input';
// eslint-disable-next-line no-unused-vars
import { ThemeToggle } from '../components/ThemeToggle';
// Using relative path to logo within src/assets
import anamnesisLogo from '../assets/anamnesis-logo.png';
import { apiRequest } from '../lib/queryClient';
import { stopStreaming } from '../lib/llm-api';

// Note: The window object is directly used where needed

/**
 * @typedef {object} Message
 * @property {string} id - Unique identifier for the message
 * @property {string} content - The message text content
 * @property {boolean} isUser - Whether the message is from the user (true) or AI (false)
 * @property {Date} timestamp - When the message was created
 */

/**
 * ChatPage component that displays the chat interface
 * @returns {JSX.Element} The ChatPage component
 */
export default function ChatPage() {
  /** @type {[Array<Message>, Function]} */
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [lastUserMessage, setLastUserMessage] = useState('');
  const [retryCount, setRetryCount] = useState(0);
  const [isFetchingHistory, setIsFetchingHistory] = useState(false);
  const [streamingMessageId, setStreamingMessageId] = useState(null);
  const [partialContent, setPartialContent] = useState('');
  const [isStoppingAI, setIsStoppingAI] = useState(false);
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);

  /**
   * Scrolls to the bottom of the chat container
   */
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  /**
   * Fetches message history from the server
   */
  const fetchMessageHistory = useCallback(async () => {
    if (!user || !user.id) return;
    
    try {
      setIsFetchingHistory(true);
      const response = await apiRequest('GET', `/api/messages/${user.id}`);
      const data = await response.json();
      
      if (data.success && Array.isArray(data.data)) {
        // Sort messages by timestamp
        const sortedMessages = [...data.data].sort(
          (a, b) => new Date(a.timestamp) - new Date(b.timestamp)
        );
        
        // Format the messages to match our client-side structure
        const formattedMessages = sortedMessages.map(msg => ({
          id: msg.id,
          content: msg.content,
          isUser: msg.isUser,
          timestamp: new Date(msg.timestamp)
        }));
        
        setMessages(formattedMessages);
      }
    } catch (error) {
      console.error('Failed to fetch message history:', error);
    } finally {
      setIsFetchingHistory(false);
    }
  }, [user]);

  /**
   * Auto-focus the input field and fetch message history on component mount
   */
  useEffect(() => {
    // Auto-focus the input field for better UX
    inputRef.current?.focus();
    
    // Fetch message history if user is logged in
    fetchMessageHistory();
  }, [fetchMessageHistory]);
  
  /**
   * Scroll to bottom when messages change
   */
  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  /**
   * Convert messages to conversation history format for API
   * @param {Array<Message>} messageList - List of messages
   * @returns {Array<{role: string, content: string}>} Conversation history
   */
  const prepareConversationHistory = (messageList) => {
    return messageList
      .filter(msg => !msg.isError) // Skip error messages in conversation history
      .map(msg => ({
        role: msg.isUser ? 'user' : 'assistant',
        content: msg.content
      }));
  };
  
  /**
   * Retry sending the last failed message
   * @param {string} messageToRetry - The message to retry sending
   * @returns {Promise<void>}
   */
  const handleRetryMessage = useCallback(async (messageToRetry) => {
    // Use either the provided message or the last saved user message
    const messageContent = messageToRetry || lastUserMessage;
    
    if (!messageContent) {
      console.warn("No message to retry");
      return;
    }
    
    setRetryCount(prev => prev + 1);
    
    // Create a retry ID by appending retry count to make it unique
    const retryId = `retry_${Date.now()}_${retryCount}`;
    
    // Find and remove the previous error message if it exists
    setMessages(prev => {
      // Keep only non-error messages in most recent conversation
      const filteredMessages = prev.filter(msg => !msg.isError || msg.timestamp < Date.now() - 30000);
      return filteredMessages;
    });
    
    // Add a new user message for the retry
    const userMessage = {
      id: retryId,
      content: messageContent,
      isUser: true,
      timestamp: new Date(),
      isRetry: true
    };
    
    setMessages(prev => [...prev, userMessage]);
    setIsLoading(true);
    
    try {
      // Prepare conversation history from previous valid messages
      const recentMessages = messages
        .filter(msg => !msg.isError)
        .slice(-6); // Use last 6 valid messages for context
      
      const conversationHistory = prepareConversationHistory(recentMessages);
      
      // Import from lib to avoid circular dependencies
      const { sendMessage } = await import('../lib/llm-api');
      
      // Create a placeholder for the AI response with streaming status
      const responseId = `${retryId}_response`;
      setMessages(prev => [
        ...prev,
        {
          id: responseId,
          content: '',
          isUser: false,
          timestamp: new Date(),
          sessionId: retryId,
          isStreaming: true,
          status: 'pending',
          metadata: {
            isStreaming: true,
            isRetry: true
          }
        }
      ]);
      
      // Set as current streaming message
      setStreamingMessageId(responseId);
      setPartialContent('');
      
      // Streaming update handler
      const handleStreamingUpdate = (content, metadata = {}) => {
        // Update the partial content for display
        setPartialContent(content);
        
        // If this is the final update (streaming complete)
        if (metadata.isComplete) {
          console.debug(`[Chat] Stream complete for retry message ${responseId}, updating status to delivered`);
          
          // Update the message with final content and metadata
          setMessages(prev => 
            prev.map(msg => 
              msg.id === responseId 
                ? {
                    ...msg,
                    content: content,
                    isStreaming: false,
                    status: 'delivered', // Ensure delivered status is set
                    metadata: {
                      ...msg.metadata,
                      ...metadata,
                      isRetry: true,
                      isStreaming: false,
                      status: 'delivered' // Also set in metadata for consistency
                    }
                  }
                : msg
            )
          );
          
          // Clear streaming state immediately to prevent any lingering animations
          setStreamingMessageId(null);
          setPartialContent('');
          
          // Force an extra render cycle to ensure animation stops
          setTimeout(() => {
            console.debug('[Chat] Forcing re-render to ensure retry animation stops');
            setMessages(prev => [...prev]);
          }, 50);
        }
      };
      
      // Call the enhanced API with streaming support
      const result = await sendMessage(
        messageContent, 
        conversationHistory,
        {}, // Default options
        handleStreamingUpdate // Streaming callback
      );
      
      // Log API metadata for monitoring/debugging
      console.info("Retry API response metadata:", result.metadata);
    } catch (error) {
      console.error('Error during retry:', error);
      
      // Get appropriate user-friendly error message
      const errorMessage = getErrorMessage(error);
      
      // If we have a streaming message in progress, convert it to an error
      if (streamingMessageId) {
        setMessages((prev) => 
          prev.map(msg => 
            msg.id === streamingMessageId 
              ? {
                  ...msg,
                  content: `${errorMessage} (Retry failed)`,
                  isStreaming: false,
                  isError: true,
                  status: 'failed',
                  originalMessage: messageContent
                }
              : msg
          )
        );
        
        // Clear streaming state
        setStreamingMessageId(null);
        setPartialContent('');
      } else {
        // Add error message
        setMessages(prev => [
          ...prev,
          {
            id: `${retryId}_error`,
            content: `${errorMessage} (Retry failed)`,
            isUser: false,
            timestamp: new Date(),
            isError: true,
            status: 'failed',
            sessionId: retryId
          }
        ]);
      }
    } finally {
      setIsLoading(false);
    }
  }, [messages, lastUserMessage, retryCount]);
  
  /**
   * Get error message based on error type
   * @param {object} error - Error object
   * @returns {string} User-friendly error message
   */
  const getErrorMessage = (error) => {
    const defaultMessage = "I'm sorry, I encountered an error processing your request. Please try again later.";
    
    if (!error) return defaultMessage;
    
    // If it's our standardized error format
    if (error.type) {
      switch (error.type) {
        case 'network':
          return "I couldn't connect to the medical knowledge system. Please check your internet connection and try again.";
        case 'timeout':
          return "It's taking longer than expected to process your medical query. Please try again or consider asking a shorter question.";
        case 'validation':
          return "Your message couldn't be processed. Please try a different question.";
        case 'api':
          return "The medical AI system is currently unavailable. Please try again in a few moments.";
        default:
          return defaultMessage;
      }
    }
    
    // Generic error
    return defaultMessage;
  };

  /**
   * Handles sending a new message
   * @param {React.FormEvent} e - The form event
   * @returns {Promise<void>}
   */
  const handleSendMessage = async (e) => {
    e.preventDefault();
    
    if (!newMessage.trim()) return;
    
    // Save the message for potential retries
    setLastUserMessage(newMessage);
    
    // Create a unique ID for this message pair
    const messageId = Date.now().toString();
    const sessionId = user?.id ? `user_${user.id}_${messageId}` : `anon_${messageId}`;
    
    // Add user message
    const userMessage = {
      id: messageId,
      content: newMessage,
      isUser: true,
      timestamp: new Date(),
      sessionId
    };
    
    setMessages((prev) => [...prev, userMessage]);
    
    // Clear input and focus it for next message
    setNewMessage('');
    inputRef.current?.focus();
    
    // Connect to the DeepSeek LLM API
    setIsLoading(true);
    
    try {
      // Prepare conversation history from previous messages
      const recentMessages = messages.slice(-6); // Use last 6 messages for context
      const conversationHistory = prepareConversationHistory(recentMessages);
      
      // Import from lib to avoid circular dependencies
      const { sendMessage } = await import('../lib/llm-api');
      
      // Create a placeholder for the AI response with streaming status
      const responseId = `${messageId}_response`;
      setMessages((prev) => [
        ...prev,
        {
          id: responseId,
          content: '',
          isUser: false,
          timestamp: new Date(),
          sessionId,
          isStreaming: true,
          status: 'pending',
          metadata: {
            isStreaming: true
          }
        }
      ]);
      
      // Set as current streaming message
      setStreamingMessageId(responseId);
      setPartialContent('');
      
      // Streaming update handler
      const handleStreamingUpdate = (content, metadata = {}) => {
        // Update the partial content for display
        setPartialContent(content);
        
        // If this is the final update (streaming complete)
        if (metadata.isComplete) {
          console.debug(`[Chat] Stream complete for message ${responseId}, updating status to delivered`);
          
          // Update the message with final content and metadata
          setMessages((prev) => 
            prev.map(msg => 
              msg.id === responseId 
                ? {
                    ...msg,
                    content: content,
                    isStreaming: false,
                    status: 'delivered', // Ensure delivered status is set
                    metadata: {
                      ...msg.metadata,
                      ...metadata,
                      isStreaming: false,
                      status: 'delivered' // Also set in metadata for consistency
                    }
                  }
                : msg
            )
          );
          
          // Clear streaming state immediately to prevent any lingering animations
          setStreamingMessageId(null);
          setPartialContent('');
          
          // Force an extra render cycle to ensure animation stops
          setTimeout(() => {
            console.debug('[Chat] Forcing re-render to ensure animation stops');
            setMessages(prev => [...prev]);
          }, 50);
        }
      };
      
      // Call the enhanced API with streaming support
      const result = await sendMessage(
        newMessage, 
        conversationHistory,
        {}, // Default options
        handleStreamingUpdate // Streaming callback
      );
      
      // Log API metadata for monitoring/debugging
      console.info("API response metadata:", result.metadata);
      
      // No need to manually save messages, as the enhanced API already handles persistence
    } catch (error) {
      console.error('Error sending message:', error);
      
      // Get appropriate user-friendly error message
      const errorMessage = getErrorMessage(error);
      
      // If we have a streaming message in progress, check if it was already delivered
      if (streamingMessageId) {
        setMessages((prev) => {
          // First, check if the message was already delivered
          const streamingMessage = prev.find(msg => msg.id === streamingMessageId);
          if (streamingMessage && streamingMessage.status === 'delivered') {
            console.debug(`Message ${streamingMessageId} already delivered, ignoring error`);
            // Don't change the message if it's already delivered
            return prev;
          }
          
          // Check if this was a deliberate abort/stop action
          const isManualAbort = error && (error.name === 'AbortError' || error.message === 'Request aborted');
          if (isManualAbort) {
            console.debug(`Message ${streamingMessageId} was manually aborted, adding cancellation message`);
            
            // Get the original message so we can extract any partial content already delivered
            const originalMessage = prev.find(msg => msg.id === streamingMessageId);
            const partialContent = originalMessage?.content || '';
            
            // Add a cancellation notice to the content
            return prev.map(msg => 
              msg.id === streamingMessageId 
                ? {
                    ...msg,
                    content: partialContent + "\n\n*AI response cancelled by user.*",
                    isStreaming: false,
                    status: 'cancelled',
                    isCancelled: true,
                    error: false // Explicitly mark as not an error
                  }
                : msg
            );
          }
          
          // Otherwise, convert it to an error
          return prev.map(msg => 
            msg.id === streamingMessageId 
              ? {
                  ...msg,
                  content: errorMessage,
                  isStreaming: false,
                  isError: true,
                  status: 'failed',
                  originalMessage: newMessage
                }
              : msg
          );
        });
        
        // Clear streaming state
        setStreamingMessageId(null);
        setPartialContent('');
      } else {
        // Add error message
        setMessages((prev) => [
          ...prev,
          {
            id: `${messageId}_error`,
            content: errorMessage,
            isUser: false,
            timestamp: new Date(),
            isError: true,
            status: 'failed',
            sessionId,
            originalMessage: newMessage // Store original message for retry functionality
          }
        ]);
      }
    } finally {
      setIsLoading(false);
    }
  };

  /**
   * Handles follow-up suggestion clicks
   * @param {string} suggestion - The suggested follow-up message
   */
  const handleFollowUpClick = (suggestion) => {
    // Set the suggestion as the new message
    setNewMessage(suggestion);
    
    // Auto-focus the input for better UX
    inputRef.current?.focus();
    
    // Optional: Auto-submit the follow-up question
    // Uncomment to enable auto-submit behavior
    // setTimeout(() => {
    //   handleSendMessage({ preventDefault: () => {} });
    // }, 100);
  };

  /**
   * Handles stopping an in-progress AI response
   */
  const handleStopAI = () => {
    if (streamingMessageId) {
      setIsStoppingAI(true);
      console.debug(`Stopping AI response for message: ${streamingMessageId}`);
      
      // DIRECT FIX: Update message with cancellation notice immediately
      setMessages(prev => 
        prev.map(msg => 
          msg.id === streamingMessageId 
            ? {
                ...msg,
                isStreaming: false,
                content: msg.content + "\n\n*AI response cancelled by user.*",
                status: 'cancelled',
                metadata: {
                  ...msg.metadata,
                  isStreaming: false,
                  isCancelled: true,
                  status: 'cancelled'
                }
              }
            : msg
        )
      );
      
      // Get the current message status before stopping
      const currentMessage = messages.find(msg => msg.id === streamingMessageId);
      const isDelivered = currentMessage?.status === 'delivered';
      
      // Call the stopStreaming function from llm-api, passing whether the message is already delivered
      const stopped = stopStreaming(isDelivered);
      
      if (!stopped) {
        console.warn("Failed to stop streaming - no active stream found");
      }
      
      // Reset the stopping state after a short delay
      setTimeout(() => {
        setIsStoppingAI(false);
      }, 300);
    }
  };

  /**
   * Handles user logout
   */
  const handleLogout = () => {
    logout();
    setLocation('/login');
  };

  return (
    <div className="min-h-screen flex flex-col bg-background transition-colors duration-300">
      {/* Header */}
      <header className="bg-card dark:bg-sidebar-background py-3 px-4 md:px-6 shadow-md border-b border-border transition-colors duration-300">
        <div className="container-xl flex flex-wrap justify-between items-center gap-y-2">
          {/* Logo and Brand */}
          <div className="flex items-center space-x-3">
            <img 
              src={anamnesisLogo} 
              alt="Anamnesis Logo" 
              className="h-10 w-auto"
            />
            <div className="border-l border-border pl-3 ml-1">
              <h1 className="text-primary text-lg font-bold">Anamnesis</h1>
              <p className="text-muted-foreground text-sm dark:text-gray-300">Medical AI Assistant</p>
            </div>
          </div>
          
          {/* Controls */}
          <div className="flex items-center space-x-2 md:space-x-4">
            {/* Theme Toggle */}
            <ThemeToggle />
            
            {/* User Email (hidden on mobile) */}
            {user && (
              <span className="hidden md:inline text-muted-foreground dark:text-gray-300 mr-2 text-sm">
                {user.email}
              </span>
            )}
            
            {/* Logout Button */}
            <Button 
              variant="outline" 
              size="sm"
              className="text-primary border-primary hover:bg-primary hover:text-primary-foreground dark:hover:text-primary-foreground font-medium transition-colors duration-200"
              onClick={handleLogout}
              aria-label="Log out of your account"
            >
              Log Out
            </Button>
          </div>
        </div>
      </header>
      
      {/* Chat Container */}
      <main className="flex-1 container-xl p-3 sm:p-4 flex flex-col overflow-hidden">
        <div 
          className="flex-1 overflow-y-auto p-3 sm:p-4 rounded-lg border border-border mb-4 bg-card shadow-sm dark:shadow-md transition-all duration-300"
          aria-live="polite"
          aria-atomic="false"
          aria-relevant="additions"
        >
          <div className="space-y-4" role="list" aria-label="Chat messages">
            {isFetchingHistory ? (
              <div className="text-center py-10 text-muted-foreground">
                <div className="inline-flex items-center justify-center space-x-2 mb-2">
                  <div className="w-5 h-5 border-2 border-primary border-t-transparent rounded-full animate-spin" aria-hidden="true"></div>
                  <span>Loading conversation history...</span>
                </div>
              </div>
            ) : messages.length === 0 ? (
              <div className="text-center py-10 px-4 text-muted-foreground animate-fade-in">
                <h3 className="text-lg md:text-xl font-medium mb-3 text-foreground">Welcome to Anamnesis Medical AI Assistant</h3>
                <p className="mb-2 text-sm sm:text-base">Ask me anything about medical symptoms, conditions, or general health questions.</p>
                <div className="mt-6 p-3 bg-secondary/50 dark:bg-secondary/30 rounded-lg max-w-md mx-auto">
                  <p className="text-sm text-foreground/80 flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                      <rect width="18" height="18" x="3" y="3" rx="2" ry="2"></rect>
                      <path d="M3 9h18"></path>
                      <path d="M9 21V9"></path>
                    </svg>
                    Your chat is private and secure
                  </p>
                </div>
                
                {/* Suggested starter questions */}
                <div className="mt-8 space-y-2">
                  <p className="text-sm font-medium text-foreground/70 mb-3">Try asking:</p>
                  <div className="flex flex-wrap justify-center gap-2">
                    {["What are symptoms of the flu?", "How can I reduce stress?", "What causes migraines?", "Is my blood pressure normal?"].map((suggestion, index) => (
                      <button
                        key={index}
                        onClick={() => handleFollowUpClick(suggestion)}
                        className="px-3 py-2 bg-blue-100 hover:bg-blue-200 text-blue-800 dark:bg-blue-800 dark:hover:bg-blue-700 dark:text-white text-sm rounded-full transition-colors shadow-sm"
                        aria-label={`Ask: ${suggestion}`}
                      >
                        {suggestion}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              messages.map((msg, index) => {
                // Determine if this message is part of a sequence of messages from the same sender
                const prevMsg = index > 0 ? messages[index - 1] : null;
                const nextMsg = index < messages.length - 1 ? messages[index + 1] : null;
                
                // Check if message is first or last in a sequence from the same sender
                const isFirst = !prevMsg || prevMsg.isUser !== msg.isUser || prevMsg.isError;
                const isLast = !nextMsg || nextMsg.isUser !== msg.isUser || msg.isError;
                
                // Only show follow-up suggestions for the last AI message in the chat
                const isLastAiMessage = !msg.isUser && 
                  (index === messages.length - 1 || messages.slice(index + 1).every(m => m.isUser));
                  
                return (
                  <MessageBubble 
                    key={msg.id}
                    message={msg.content}
                    isUser={msg.isUser}
                    timestamp={msg.timestamp}
                    isError={msg.isError}
                    isHighRisk={Boolean(msg.isHighRisk || (msg.metadata && msg.metadata.isHighRisk))}
                    metadata={msg.metadata}
                    originalMessage={msg.originalMessage}
                    onRetry={handleRetryMessage}
                    onFollowUpClick={handleFollowUpClick}
                    showFollowUps={isLastAiMessage && !msg.isError}
                    isFirst={isFirst}
                    isLast={isLast}
                    onStopAI={!msg.isUser && streamingMessageId === msg.id ? handleStopAI : undefined}
                    isStoppingAI={isStoppingAI}
                    isStreaming={msg.id === streamingMessageId}
                    partialContent={msg.id === streamingMessageId ? partialContent : ''}
                    status={msg.status || 'sent'}
                  />
                );
              })
            )}
            
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-primary/10 text-primary rounded-lg p-3 max-w-[80%]">
                  <div className="flex space-x-2">
                    <div className="w-2 h-2 rounded-full bg-primary animate-bounce"></div>
                    <div className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    <div className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: '0.4s' }}></div>
                  </div>
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>
        </div>
        
        {/* Message Input */}
        <form onSubmit={handleSendMessage} className="flex space-x-2 relative">
          <Input
            ref={inputRef}
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Type your medical question..."
            className="flex-1 h-12 sm:h-14 px-4 py-3 rounded-full border-border shadow-sm focus:ring-2 focus:ring-primary/30 dark:bg-sidebar-background transition-all duration-200"
            disabled={isLoading || isFetchingHistory}
            type="text"
            aria-label="Message input"
            maxLength={1000}
            showCharCount={true}
            onEnterPress={(e) => {
              if (newMessage.trim()) {
                handleSendMessage(e);
              }
            }}
          />
          <Button 
            type="submit" 
            disabled={isLoading || isFetchingHistory || !newMessage.trim()}
            aria-label="Send message"
            className="h-12 sm:h-14 px-5 sm:px-6 rounded-full bg-primary hover:bg-primary-900 focus:ring-2 focus:ring-primary/20 focus:ring-offset-2 transition-all duration-200 text-primary-foreground font-medium"
          >
            {isLoading ? (
              <div className="typing-indicator" aria-label="Message is being sent">
                <span></span>
                <span></span>
                <span></span>
              </div>
            ) : (
              <span className="flex items-center">
                <span className="mr-1">Send</span>
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="ml-1">
                  <path d="m22 2-7 20-4-9-9-4Z" />
                  <path d="M22 2 11 13" />
                </svg>
              </span>
            )}
          </Button>
        </form>
        
        {/* Accessibility hint */}
        <div className="text-center mt-3 text-xs text-muted-foreground opacity-70 hidden sm:block" aria-hidden="true">
          Press Enter to send • Shift+Enter for new line
        </div>
      </main>
    </div>
  );
}