import React, { useState } from 'react';
import { useLocation } from 'wouter';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Checkbox } from '../components/ui/checkbox';
import { SocialLoginButton } from '../components/SocialLoginButton';
// eslint-disable-next-line no-unused-vars
import { ThemeToggle } from '../components/ThemeToggle.jsx';
// Social provider icons
import { FcGoogle } from 'react-icons/fc';
import { FaMicrosoft, FaApple } from 'react-icons/fa';
// Import logo
import anamnesisLogo from '../assets/anamnesis-logo.png';
// Auth hook
import { useAuth } from '../hooks/useAuth';
// We no longer need to import directly from supabase since useAuth manages this
// Toast notifications
import { useToast } from '../components/ToastProvider';

/**
 * LoginPage component that handles user authentication
 * @returns {JSX.Element} The LoginPage component
 */
export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [isRegister, setIsRegister] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [emailConfirmation, setEmailConfirmation] = useState(false);
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [privacyAccepted, setPrivacyAccepted] = useState(false);
  const [medicalDisclaimerAccepted, setMedicalDisclaimerAccepted] = useState(false);
  const [showLegalInfo, setShowLegalInfo] = useState(false);
  const { login, register, isLoading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  /**
   * Clears any error messages
   * @returns {void} No return value
   */
  const clearError = () => {
    setError('');
    setEmailConfirmation(false);
  };

  /**
   * Toggle between login and registration mode
   * @returns {void} No return value
   */
  const toggleRegisterMode = () => {
    clearError();
    setIsRegister(!isRegister);
    // Reset legal acceptances when toggling modes
    setTermsAccepted(false);
    setPrivacyAccepted(false);
    setMedicalDisclaimerAccepted(false);
  };

  /**
   * Toggle legal information display
   * @returns {void} No return value
   */
  const toggleLegalInfo = () => {
    setShowLegalInfo(!showLegalInfo);
  };

  /**
   * Handles form submission
   * @param {React.FormEvent} e - Form event
   * @returns {Promise<void>} Async function
   */
  const handleSubmit = async (e) => {
    e.preventDefault();
    clearError();
    
    // Basic validation
    if (!email) {
      setError('Please enter an email address');
      return;
    }
    
    if (!password) {
      setError('Please enter a password');
      return;
    }
    
    if (isRegister && !name) {
      setError('Please enter your name');
      return;
    }

    // Legal acceptance validation for registration
    if (isRegister) {
      if (!termsAccepted) {
        setError('You must accept the Terms of Service');
        return;
      }
      
      if (!privacyAccepted) {
        setError('You must accept the Privacy Policy');
        return;
      }
      
      if (!medicalDisclaimerAccepted) {
        setError('You must accept the Medical Information Disclaimer');
        return;
      }
    }
    
    setIsLoading(true);
    
    try {
      if (isRegister) {
        // Handle registration
        const { success, error, confirmEmail } = await register(email, password, { name });
        if (success) {
          if (confirmEmail) {
            setEmailConfirmation(true);
          } else {
            toast({
              title: "Account created!",
              description: "Your account has been successfully created.",
              variant: "success"
            });
            setLocation('/chat');
          }
        } else {
          setError(error || 'Registration failed');
        }
      } else {
        // Handle login
        const { success, error } = await login(email, password);
        if (success) {
          toast({
            title: "Login successful",
            description: "Welcome back to Anamnesis!",
            variant: "success"
          });
          setLocation('/chat');
        } else {
          setError(error || 'Invalid credentials');
        }
      }
    } catch (err) {
      setError(err.message || 'Authentication failed');
      console.error('Authentication error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  /**
   * Handles social login authentication
   * @param {string} provider - The OAuth provider
   * @returns {Function} Event handler function
   */
  const handleSocialLogin = (provider) => async (e) => {
    e.preventDefault();
    clearError();
    setIsLoading(true);
    
    try {
      // This feature is not fully implemented in the current version
      // In a production environment, we would implement OAuth here
      
      // Show toast notification for unimplemented feature
      toast({
        title: "Not implemented",
        description: `${provider} authentication will be available in a future release.`,
        variant: "warning"
      });
      
      // For demo, show mock error to inform user
      setError(`${provider} login is not available in this MVP version.`);
    } catch (err) {
      console.error(`${provider} login error:`, err);
      setError(`${provider} login encountered an error: ${err.message || 'Unknown error'}`);
    } finally {
      setIsLoading(false);
    }
  };

  /**
   * Renders the email confirmation message
   * @type {React.FC}
   */
  // Integrating component into the main component to avoid ESLint unused var warnings
  function renderEmailConfirmation() {
    return (
      <div className="text-center py-6">
        <div className="mb-4 bg-green-100 text-green-800 p-4 rounded-md">
          <h4 className="font-semibold text-lg mb-2">Confirmation Email Sent!</h4>
          <p>
            We've sent a confirmation link to <strong>{email}</strong>.
            Please check your inbox and click the link to verify your account.
          </p>
        </div>
        <p className="mb-4 text-muted-foreground">
          Didn't receive the email? Check your spam folder or try again.
        </p>
        <div className="flex gap-3 justify-center">
          <Button
            variant="outline"
            onClick={toggleRegisterMode}
          >
            Return to Login
          </Button>
          <Button
            onClick={() => {
              setEmailConfirmation(false);
              setEmail('');
              setPassword('');
              setName('');
            }}
          >
            Register Another Account
          </Button>
        </div>
      </div>
    );
  }

  /**
   * Renders the legal information component with full policy details
   * @returns {JSX.Element} Legal information JSX
   */
  function renderLegalInformation() {
    return (
      <div className="mt-4 p-4 border border-gray-200 rounded-md bg-gray-50 text-sm text-muted-foreground overflow-auto max-h-60">
        <div className="mb-4">
          <h4 className="font-semibold text-foreground">Terms of Service</h4>
          <p>These Terms of Service ("Terms") govern your access to and use of Anamnesis Medical AI Assistant ("Anamnesis"). By using Anamnesis, you agree to be bound by these Terms.</p>
          <p className="mt-1">Anamnesis provides an AI-powered conversational interface for healthcare information. This service is provided for informational purposes only and is not a substitute for professional medical advice, diagnosis, or treatment.</p>
          <p className="mt-1">We reserve the right to modify these Terms at any time. Your continued use of Anamnesis after such modifications constitutes your agreement to the updated Terms.</p>
        </div>
        
        <div className="mb-4">
          <h4 className="font-semibold text-foreground">Privacy Policy</h4>
          <p>Your privacy is important to us. Our Privacy Policy explains how we collect, use, and safeguard your information when you use Anamnesis.</p>
          <p className="mt-1">We collect information you provide directly, including account information, messages, and usage data. This information is used to provide and improve our services, communicate with you, and comply with legal obligations.</p>
          <p className="mt-1">We implement appropriate security measures to protect your personal information but cannot guarantee absolute security. You are responsible for maintaining the confidentiality of your account credentials.</p>
        </div>
        
        <div>
          <h4 className="font-semibold text-foreground">Medical Information Disclaimer</h4>
          <p>Anamnesis is not a substitute for professional medical advice, diagnosis, or treatment. Always seek the advice of qualified healthcare providers with any questions regarding your health.</p>
          <p className="mt-1">The content provided by Anamnesis is for informational purposes only. It may not be accurate, complete, or up-to-date. Do not disregard professional medical advice or delay seeking it because of information provided by Anamnesis.</p>
          <p className="mt-1">Medical emergencies require immediate medical attention. If you are experiencing a medical emergency, call your doctor or emergency services immediately.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col justify-center py-8 sm:py-12 px-4 sm:px-6 lg:px-8 bg-background dark:bg-background transition-colors duration-300">
      <div className="container-sm max-w-md mx-auto">
        {/* Theme toggle positioned at the top right */}
        <div className="absolute top-4 right-4">
          <ThemeToggle />
        </div>
        
        <div className="text-center mb-8">
          <div className="flex justify-center mb-2">
            <img 
              src={anamnesisLogo} 
              alt="Anamnesis Logo" 
              className="h-20 sm:h-24 w-auto animate-fade-in"
            />
          </div>
          <h1 className="h1 text-primary mb-1 font-bold">Anamnesis</h1>
          <h2 className="h3 mb-2 text-foreground">Medical AI Assistant</h2>
          <p className="text-muted-foreground text-sm">Your personal healthcare companion</p>
        </div>

        <div className="bg-card dark:bg-card shadow-lg rounded-xl p-6 sm:p-8 border border-border transition-all duration-300 animate-fade-in">
          {emailConfirmation ? renderEmailConfirmation() : (
            <>
              <h3 className="text-xl font-bold text-center mb-6 text-foreground">
                {isRegister ? 'Create Account' : 'Sign In'}
              </h3>
              <form onSubmit={handleSubmit} className="space-y-5">
                {/* Name field - only shown for registration */}
                {isRegister && (
                  <div className="transition-all duration-200 animate-fade-in">
                    <label htmlFor="name" className="block text-sm font-medium text-foreground dark:text-foreground/90 mb-1.5">
                      Name
                    </label>
                    <Input
                      id="name"
                      type="text"
                      placeholder="Enter your name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full h-11 transition-colors duration-200 bg-background dark:bg-sidebar-background border-border"
                      required
                      aria-required="true"
                      aria-label="Your full name"
                    />
                  </div>
                )}
                
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-foreground dark:text-foreground/90 mb-1.5">
                    Email
                  </label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="Enter your email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full h-11 transition-colors duration-200 bg-background dark:bg-sidebar-background border-border focus:ring-2 focus:ring-primary/30"
                    required
                    aria-required="true"
                    aria-label="Your email address"
                  />
                </div>
                
                <div>
                  <label htmlFor="password" className="block text-sm font-medium text-foreground dark:text-foreground/90 mb-1.5">
                    Password
                  </label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="Enter your password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full h-11 transition-colors duration-200 bg-background dark:bg-sidebar-background border-border focus:ring-2 focus:ring-primary/30"
                    required
                    minLength={6}
                    aria-required="true"
                    aria-label="Your password"
                  />
                  <p className="text-xs text-muted-foreground mt-1.5">
                    Password must be at least 6 characters long
                  </p>
                </div>
                
                {error && (
                  <div className="text-destructive text-sm p-3 bg-destructive/10 dark:bg-destructive/20 rounded-md mt-2 border border-destructive/20 animate-fade-in">
                    <p className="flex items-center">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="12" y1="8" x2="12" y2="12"></line>
                        <line x1="12" y1="16" x2="12.01" y2="16"></line>
                      </svg>
                      {error}
                    </p>
                  </div>
                )}
                
                {/* Toggle between login and registration */}
                <div className="flex flex-wrap justify-between items-center text-sm mt-4">
                  <button 
                    type="button"
                    className="text-primary hover:text-primary-900 dark:hover:text-primary-500 transition-colors duration-200 bg-transparent border-none p-0 cursor-pointer focus:outline-none focus:ring-2 focus:ring-primary/20 focus:ring-offset-2 rounded px-2 py-1 -ml-2"
                    onClick={toggleRegisterMode}
                    aria-label={isRegister ? "Switch to login" : "Switch to registration"}
                  >
                    {isRegister ? 'Already have an account? Sign In' : 'Need an account? Register'}
                  </button>
                  
                  {!isRegister && (
                    <a 
                      href="#" 
                      className="text-primary hover:text-primary-900 dark:hover:text-primary-500 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:ring-offset-2 rounded px-2 py-1"
                      aria-label="Reset your forgotten password"
                    >
                      Forgot password?
                    </a>
                  )}
                </div>
                
                <div className="pt-6">
                  {/* Legal disclaimers - only shown for registration */}
                  {isRegister && (
                    <div className="space-y-4 mb-6">
                      <div className="flex items-center space-x-2">
                        <Checkbox 
                          id="terms" 
                          checked={termsAccepted}
                          onCheckedChange={setTermsAccepted}
                          required
                          className="text-primary border-border data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground focus:ring-2 focus:ring-primary/30"
                          aria-required="true"
                        />
                        <label
                          htmlFor="terms"
                          className="text-sm font-medium text-foreground dark:text-foreground/90 leading-tight peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          I accept the <button 
                            type="button" 
                            onClick={toggleLegalInfo}
                            className="text-primary hover:text-primary-900 dark:hover:text-primary-500 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:ring-offset-1 rounded"
                          >
                            Terms of Service
                          </button>
                        </label>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <Checkbox 
                          id="privacy" 
                          checked={privacyAccepted}
                          onCheckedChange={setPrivacyAccepted}
                          required
                          className="text-primary border-border data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground focus:ring-2 focus:ring-primary/30"
                          aria-required="true"
                        />
                        <label
                          htmlFor="privacy"
                          className="text-sm font-medium text-foreground dark:text-foreground/90 leading-tight peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          I accept the <button 
                            type="button" 
                            onClick={toggleLegalInfo}
                            className="text-primary hover:text-primary-900 dark:hover:text-primary-500 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:ring-offset-1 rounded"
                          >
                            Privacy Policy
                          </button>
                        </label>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <Checkbox 
                          id="medical" 
                          checked={medicalDisclaimerAccepted}
                          onCheckedChange={setMedicalDisclaimerAccepted}
                          required
                          className="text-primary border-border data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground focus:ring-2 focus:ring-primary/30"
                          aria-required="true"
                        />
                        <label
                          htmlFor="medical"
                          className="text-sm font-medium text-foreground dark:text-foreground/90 leading-tight peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          I understand the <button 
                            type="button" 
                            onClick={toggleLegalInfo}
                            className="text-primary hover:text-primary-900 dark:hover:text-primary-500 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:ring-offset-1 rounded"
                          >
                            Medical Information Disclaimer
                          </button>
                        </label>
                      </div>
                      
                      {showLegalInfo && (
                        <div className="mt-4 animate-fade-in">
                          {renderLegalInformation()}
                        </div>
                      )}
                    </div>
                  )}
                
                  <Button
                    type="submit"
                    className="w-full h-11 sm:h-12 py-2 text-base font-medium mt-2 bg-primary hover:bg-primary-900 dark:hover:bg-primary-700 text-primary-foreground rounded-lg transition-all duration-200 focus:ring-2 focus:ring-primary/40 focus:ring-offset-2"
                    disabled={
                      isLoading || 
                      authLoading || 
                      !email || 
                      !password || 
                      (isRegister && !name) ||
                      (isRegister && (!termsAccepted || !privacyAccepted || !medicalDisclaimerAccepted))
                    }
                  >
                    {isLoading || authLoading ? (
                      <div className="flex items-center justify-center">
                        <div className="w-5 h-5 border-2 border-primary-foreground border-t-transparent rounded-full animate-spin mr-2"></div>
                        <span>{isRegister ? 'Creating Account...' : 'Signing In...'}</span>
                      </div>
                    ) : (
                      <span className="flex items-center justify-center">
                        {isRegister ? 'Create Account' : 'Sign In'}
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="ml-2">
                          <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4" />
                          <polyline points="10 17 15 12 10 7" />
                          <line x1="15" y1="12" x2="3" y2="12" />
                        </svg>
                      </span>
                    )}
                  </Button>
                </div>
                
                {/* Divider */}
                <div className="relative my-6">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-border dark:border-border/70"></div>
                  </div>
                  <div className="relative flex justify-center text-sm">
                    <span className="px-3 bg-card dark:bg-card text-muted-foreground">
                      or continue with
                    </span>
                  </div>
                </div>
                
                {/* Social Login Buttons */}
                <div className="space-y-3">
                  <SocialLoginButton 
                    icon={<FcGoogle size={20} />} 
                    provider="Google" 
                    onClick={handleSocialLogin('Google')}
                    disabled={isLoading || authLoading}
                    className="w-full h-11 bg-background dark:bg-sidebar-background hover:bg-gray-100 dark:hover:bg-gray-800 border-border dark:border-border/70 text-foreground dark:text-foreground transition-colors duration-200 focus:ring-2 focus:ring-primary/20"
                    aria-label="Sign in with Google"
                  />
                  <SocialLoginButton 
                    icon={<FaMicrosoft size={18} className="text-blue-600 dark:text-blue-500" />} 
                    provider="Microsoft" 
                    onClick={handleSocialLogin('Microsoft')}
                    disabled={isLoading || authLoading}
                    className="w-full h-11 bg-background dark:bg-sidebar-background hover:bg-gray-100 dark:hover:bg-gray-800 border-border dark:border-border/70 text-foreground dark:text-foreground transition-colors duration-200 focus:ring-2 focus:ring-primary/20"
                    aria-label="Sign in with Microsoft"
                  />
                  <SocialLoginButton 
                    icon={<FaApple size={18} className="dark:text-gray-300" />} 
                    provider="Apple" 
                    onClick={handleSocialLogin('Apple')}
                    disabled={isLoading || authLoading}
                    className="w-full h-11 bg-background dark:bg-sidebar-background hover:bg-gray-100 dark:hover:bg-gray-800 border-border dark:border-border/70 text-foreground dark:text-foreground transition-colors duration-200 focus:ring-2 focus:ring-primary/20"
                    aria-label="Sign in with Apple"
                  />
                </div>
                
                <div className="text-center text-sm text-muted-foreground mt-4">
                  <p>
                    For testing, use demo@example.com / password
                  </p>
                </div>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  );
}