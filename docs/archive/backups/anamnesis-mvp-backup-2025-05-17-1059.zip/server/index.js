/**
 * @file Entry point for the Anamnesis Medical AI Assistant server
 */

import express from "express";
import dotenv from "dotenv";
import { registerRoutes } from "./routes.js";
import { log, setupVite, serveStatic } from "./vite.js";
// Removed unused imports: path, fileURLToPath

// Load environment variables
dotenv.config();

// Create Express app
const app = express();

// Configure middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Add CORS headers for development
if (process.env.NODE_ENV === "development") {
  app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET, PUT, POST, DELETE");
    res.header(
      "Access-Control-Allow-Headers",
      "Origin, X-Requested-With, Content-Type, Accept, Authorization"
    );
    next();
  });
}

// Global error handler
app.use((err, _req, res, _next) => {
  console.error(err.stack);
  const statusCode = err.statusCode || 500;
  const message = err.message || "Internal Server Error";
  res.status(statusCode).json({ error: message });
});

// First register API routes to ensure they take precedence
registerRoutes(app).then((apiServer) => {
  // Then set up Vite in development (after API routes) or serve static files in production
  if (process.env.NODE_ENV === "development") {
    setupVite(app)
      .then(() => {
        const PORT = process.env.PORT || 5000;
        
        apiServer.listen(PORT, () => {
          log(`serving on port ${PORT}`);
        });
      })
      .catch((err) => {
        console.error("Error setting up server:", err);
        process.exit(1);
      });
  } else {
    // Serve static files in production
    serveStatic(app);
    
    const PORT = process.env.PORT || 5000;
    
    apiServer.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  }
}).catch(err => {
  console.error("Error registering API routes:", err);
  process.exit(1);
});

process.on("uncaughtException", (err) => {
  console.error("Uncaught Exception:", err);
});

process.on("unhandledRejection", (reason, promise) => {
  console.error("Unhandled Rejection at:", promise, "reason:", reason);
});