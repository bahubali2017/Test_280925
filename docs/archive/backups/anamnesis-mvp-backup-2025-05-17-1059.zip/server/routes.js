/**
 * @file API routes for the Anamnesis Medical AI Assistant
 */

import express from "express";
import { createServer } from "http";
import { storage } from "./storage.js";
import { z } from "zod";
import { authenticateUser, createUser, verifyToken } from "./auth-api.js";
import messageApiRouter from "./api/message-api.js";
import directEndpoints from "./api/direct-endpoints.js";
import { setTimeout } from "timers";
import { TextDecoder } from "util";

// Import the test connection function
import testSupabaseConnection from "./test-connection.js";

/**
 * Schema for validating chat API requests with enhanced options for Phase 4
 * @type {import('zod').ZodObject<{
 *   message: import('zod').ZodString,
 *   conversationHistory: import('zod').ZodArray<import('zod').ZodObject<{
 *     role: import('zod').ZodString,
 *     content: import('zod').ZodString
 *   }>>,
 *   isHighRisk: import('zod').ZodBoolean
 * }>}
 */
const chatRequestSchema = z.object({
  message: z.string().min(1, "Message cannot be empty").max(4000, "Message is too long"),
  conversationHistory: z.array(
    z.object({
      role: z.string().min(1),
      content: z.string().min(1)
    })
  ).optional().default([]),
  isHighRisk: z.boolean().optional().default(false)
});

/**
 * Schema for validating login requests
 * @type {import('zod').ZodObject<{email: import('zod').ZodString, password: import('zod').ZodString}>}
 */
const loginRequestSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

/**
 * Schema for validating registration requests
 * @type {import('zod').ZodObject<{email: import('zod').ZodString, password: import('zod').ZodString, name: import('zod').ZodString}>}
 */
const registerRequestSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  name: z.string().min(1, "Name is required"),
});

/**
 * Schema for validating token verification requests
 * @type {import('zod').ZodObject<{token: import('zod').ZodString}>}
 */
const verifyTokenSchema = z.object({
  token: z.string().min(1, "Token is required"),
});

/**
 * Gets DeepSeek configuration from environment variables
 * @returns {object} The DeepSeek configuration
 */
function getDeepSeekConfig() {
  // Configuration is now defined inline
  return {
    apiKey: process.env.DEEPSEEK_API_KEY || "",
    model: "deepseek-chat",
    temperature: 0.7,
    maxTokens: 2000,
    endpoint: "https://api.deepseek.com/v1/chat/completions",
  };
}

/**
 * Registers API routes
 * @param {import('express').Express} app - The Express application
 * @returns {Promise<import('http').Server>} The HTTP server
 */
export async function registerRoutes(app) {
  const apiRouter = express.Router();

  // Run the test connection on startup
  try {
    await testSupabaseConnection();
  } catch (error) {
    console.error("Supabase connection test failed:", error.message);
    // Continue - we don't want to block the server from starting
  }

  /**
   * Health check endpoint
   */
  apiRouter.get("/health", (req, res) => {
    const config = getDeepSeekConfig();
    res.json({ 
      status: "ok", 
      timestamp: new Date().toISOString(),
      api: {
        deepseek: {
          available: !!config.apiKey,
          model: config.model
        },
        routes: {
          chat: "/api/chat",
          chat_stream: "/api/chat/stream",
          messages: "/api/messages"
        }
      }
    });
  });
  
  /**
   * Chat API test endpoint to check if the API routes are correctly mounted
   */
  apiRouter.get("/chat/test", (req, res) => {
    res.json({ 
      status: "ok", 
      message: "Chat API is available",
      routes: {
        standard: "/api/chat",
        streaming: "/api/chat/stream"
      },
      timestamp: new Date().toISOString() 
    });
  });

  /**
   * Authentication endpoints
   */
  apiRouter.post("/auth/login", async (req, res) => {
    try {
      // Validate request
      const validation = loginRequestSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({
          success: false,
          message: "Invalid request",
          errors: validation.error.errors,
        });
      }

      const { email, password } = validation.data;
      const result = await authenticateUser(email, password);

      if (!result.success) {
        return res.status(401).json({
          success: false,
          message: result.error || "Authentication failed",
        });
      }

      return res.json({
        success: true,
        message: "Authentication successful",
        user: {
          id: result.user.id,
          email: result.user.email,
          name: result.user.user_metadata?.name || "",
        },
        token: result.token,
      });
    } catch (error) {
      console.error("Login error:", error);
      return res.status(500).json({
        success: false,
        message: "Internal server error",
      });
    }
  });

  apiRouter.post("/auth/register", async (req, res) => {
    try {
      // Validate request
      const validation = registerRequestSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({
          success: false,
          message: "Invalid request",
          errors: validation.error.errors,
        });
      }

      const { email, password, name } = validation.data;
      const result = await createUser(email, password, { name });

      if (!result.success) {
        return res.status(400).json({
          success: false,
          message: result.error || "Registration failed",
        });
      }

      return res.json({
        success: true,
        message: "Registration successful",
        user: {
          id: result.user.id,
          email: result.user.email,
          name: result.user.user_metadata?.name || "",
        },
      });
    } catch (error) {
      console.error("Registration error:", error);
      return res.status(500).json({
        success: false,
        message: "Internal server error",
      });
    }
  });

  apiRouter.post("/auth/verify", async (req, res) => {
    try {
      // Validate request
      const validation = verifyTokenSchema.safeParse(req.body);
      if (!validation.success) {
        return res.status(400).json({
          success: false,
          message: "Invalid request",
          errors: validation.error.errors,
        });
      }

      const { token } = validation.data;
      const result = await verifyToken(token);

      if (!result.success) {
        return res.status(401).json({
          success: false,
          message: result.error || "Token verification failed",
        });
      }

      return res.json({
        success: true,
        message: "Token verification successful",
        user: {
          id: result.user.id,
          email: result.user.email,
          name: result.user.user_metadata?.name || "",
        },
      });
    } catch (error) {
      console.error("Token verification error:", error);
      return res.status(500).json({
        success: false,
        message: "Internal server error",
      });
    }
  });

  /**
   * Chat endpoint for processing messages with DeepSeek API
   * Enhanced for Phase 4 with conversation history, retry logic, safety features, and streaming support
   */
  apiRouter.post("/chat", async (req, res) => {
    try {
      // Start timing the request for analytics
      const startTime = Date.now();
      
      // Generate a unique session ID if not provided
      const sessionId = req.headers['x-session-id'] || `session_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`;
      
      // Validate request
      const validation = chatRequestSchema.safeParse(req.body);
      if (!validation.success) {
        console.warn("Invalid chat request:", validation.error.errors);
        return res.status(400).json({
          success: false,
          message: "Invalid request",
          errors: validation.error.errors,
        });
      }

      const { message, conversationHistory, isHighRisk } = validation.data;
      const config = getDeepSeekConfig();

      if (!config.apiKey) {
        console.error("Missing DeepSeek API key");
        return res.status(500).json({
          success: false,
          message: "DeepSeek API key is missing. Please set the DEEPSEEK_API_KEY environment variable.",
        });
      }
      
      // Log the incoming request for analytics
      console.info(`[${sessionId}] Processing chat request${isHighRisk ? ' (HIGH RISK)' : ''}: ${message.substring(0, 100)}${message.length > 100 ? '...' : ''}`);
      
      // Prepare messages array with enhanced system context and conversation history
      const medicalContext = `You are MAIA (Medical AI Assistant) from Anamnesis, a sophisticated medical assistant designed to provide accurate, 
        evidence-based health information while maintaining a compassionate, professional tone.

        ## Core Guidelines:
        1. Always clarify that you are not providing medical advice and users should consult healthcare professionals for diagnosis and treatment.
        2. Be thorough, accurate, and cite trustworthy medical information from established sources when possible.
        3. Use plain language and avoid jargon when speaking to non-professionals.
        4. Adapt your language to match the technical level of the question (clinical language for professional queries).
        5. Structure your answers in a clear, organized way with appropriate paragraphs and bullet points when helpful.
        
        ## Safety & Disclaimers:
        - For any potentially serious symptoms (chest pain, difficulty breathing, severe bleeding, loss of consciousness), begin your response with a clear emergency disclaimer.
        - Never suggest specific medications, dosages, or treatments; instead discuss general treatment approaches mentioned in medical guidelines.
        - If a query relates to mental health crisis, always emphasize the importance of immediate professional help.
        
        ## Response Style:
        - Begin with a brief, direct answer to the main question
        - Follow with relevant context and deeper explanation
        - Include common causes, symptoms or related information as appropriate
        - Close with a reminder about consulting healthcare professionals when needed
        - Show empathy and understanding, especially for sensitive health topics
        
        ## What to Avoid:
        - Do not collect or request personal identifying information (name, address, etc.)
        - Avoid definitive diagnostic statements like "you have X condition"
        - Do not claim to replace proper medical consultation
        - Refrain from commenting on the efficacy of alternative/unproven treatments
        
        Remember that your purpose is to inform and educate, not diagnose or treat. Focus on providing factual, 
        evidence-based information presented in a way that's helpful and easy to understand.`;
      
      const messages = [
        { role: "system", content: medicalContext }
      ];
      
      // Add conversation history if available
      if (conversationHistory && conversationHistory.length > 0) {
        // Add only the last 10 messages to avoid token limits
        messages.push(...conversationHistory.slice(-10));
      }
      
      // Add the current message
      messages.push({ role: "user", content: message });
      
      // Make API request with timeout and retry logic
      const maxRetries = 2;
      const timeoutMs = 15000; // 15 seconds timeout
      
      let lastError = null;
      let attemptsMade = 0;
      
      for (let attempt = 0; attempt <= maxRetries; attempt++) {
        attemptsMade++;
        
        try {
          // Create timeout promise
          const timeoutPromise = new Promise((_, reject) => {
            setTimeout(() => reject(new Error('Request timed out')), timeoutMs);
          });
          
          // Create fetch promise with all messages
          const fetchPromise = fetch(config.endpoint, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Authorization": `Bearer ${config.apiKey}`,
            },
            body: JSON.stringify({
              model: config.model,
              messages: messages,
              temperature: config.temperature,
              max_tokens: config.maxTokens,
            }),
          });
          
          // Race the promises
          const deepSeekResponse = await Promise.race([fetchPromise, timeoutPromise]);
          
          if (!deepSeekResponse.ok) {
            const errorData = await deepSeekResponse.text();
            console.error(`[${sessionId}] DeepSeek API error (attempt ${attempt + 1}/${maxRetries + 1}):`, errorData);
            
            // For certain status codes, we don't retry
            if (deepSeekResponse.status === 401 || deepSeekResponse.status === 403) {
              return res.status(deepSeekResponse.status).json({
                success: false,
                message: `Authentication error with DeepSeek API: ${deepSeekResponse.statusText}`,
                error_type: "authentication",
              });
            }
            
            lastError = new Error(`DeepSeek API error: ${deepSeekResponse.statusText}`);
            // Continue to retry for other error types
          } else {
            // Success - process the response
            const data = await deepSeekResponse.json();
            const aiResponse = data.choices[0]?.message?.content;
            
            if (!aiResponse) {
              console.error(`[${sessionId}] Empty response from DeepSeek API`);
              return res.status(500).json({
                success: false,
                message: "No response generated from DeepSeek API",
                error_type: "empty_response",
              });
            }
            
            // Log the response time
            const requestDuration = Date.now() - startTime;
            console.info(`[${sessionId}] DeepSeek API request completed in ${requestDuration}ms (attempt ${attempt + 1})`);
            
            // Use authenticated user ID if available, otherwise default to anonymous
            const userId = req.user?.id || "anonymous";
            
            // Create metadata for messages
            const messageMetadata = { 
              timestamp: new Date(),
              sessionId,
              isHighRisk,
              requestTime: requestDuration,
            };
            
            // Save user message with metadata
            await storage.saveMessage(userId, message, true, {
              ...messageMetadata,
              type: 'user_message'
            });
            
            // Save AI response with metadata including tokens
            await storage.saveMessage(userId, aiResponse, false, {
              ...messageMetadata,
              type: 'ai_response',
              promptTokens: data.usage?.prompt_tokens,
              completionTokens: data.usage?.completion_tokens,
              totalTokens: data.usage?.total_tokens
            });
            
            // Return success response with full metadata
            return res.json({
              success: true,
              response: aiResponse,
              metadata: {
                sessionId,
                isHighRisk,
                requestTime: requestDuration,
                attemptsMade,
                modelName: data.model || config.model,
              },
              usage: {
                prompt_tokens: data.usage?.prompt_tokens,
                completion_tokens: data.usage?.completion_tokens,
                total_tokens: data.usage?.total_tokens
              }
            });
          }
        } catch (error) {
          console.error(`[${sessionId}] Error during attempt ${attempt + 1}/${maxRetries + 1}:`, error);
          lastError = error;
          
          // If this isn't the last attempt, wait before retrying
          if (attempt < maxRetries) {
            const retryDelay = 1000 * Math.pow(2, attempt); // Exponential backoff
            console.info(`[${sessionId}] Retrying in ${retryDelay}ms...`);
            await new Promise(resolve => setTimeout(resolve, retryDelay));
          }
        }
      }
      
      // If we got here, all attempts failed
      console.error(`[${sessionId}] All ${maxRetries + 1} attempts failed.`);
      
      // Return a friendly error message
      return res.status(500).json({
        success: false,
        message: "We're having trouble connecting to our AI service. Please try again in a moment.",
        error_type: lastError?.name === 'AbortError' || lastError?.message?.includes('timed out') 
          ? "timeout" 
          : "service_unavailable",
        metadata: {
          sessionId,
          isHighRisk,
          attemptsMade,
          requestTime: Date.now() - startTime,
        }
      });
    } catch (error) {
      console.error("Chat API error:", error);
      return res.status(500).json({
        success: false,
        message: `We encountered an unexpected problem. Please try again.`,
        detail: process.env.NODE_ENV === 'development' ? error.message : undefined
      });
    }
  });

  /**
   * Streaming chat endpoint for real-time message processing
   * Implements Server-Sent Events (SSE) for streaming responses
   */
  /**
   * GET /api/messages/:userId - Direct API endpoint to get messages for a user
   * Added directly in routes.js to ensure availability
   */
  apiRouter.get("/messages/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const limit = req.query.limit ? parseInt(req.query.limit, 10) : 50;
      
      if (!userId) {
        return res.status(400).json({ 
          success: false, 
          message: 'User ID is required' 
        });
      }
      
      console.log(`Direct route: Fetching messages for user ${userId} with limit ${limit}`);
      
      // Fetch messages from database
      const messages = await storage.getMessages(userId, limit);
      
      console.log(`Direct route: Retrieved ${messages.length} messages for user ${userId}`);
      
      return res.json({
        success: true,
        data: messages
      });
    } catch (err) {
      console.error('Failed to fetch messages:', err);
      return res.status(500).json({ 
        success: false, 
        message: 'Failed to fetch messages' 
      });
    }
  });
  
  /**
   * Generates a simulated medical response based on user query
   * This function is kept for reference but now replaced with DeepSeek integration
   * @param {string} userMessage - The user's message
   * @param {boolean} isHighRisk - Whether the message is flagged as high risk
   * @returns {string} The simulated AI response
   * @private
   */
  // eslint-disable-next-line no-unused-vars
  function _generateMedicalResponse(userMessage, isHighRisk) {
    // Add emergency disclaimer for high-risk messages
    let response = '';
    
    if (isHighRisk) {
      response += '**IMPORTANT MEDICAL DISCLAIMER**: If you are experiencing a medical emergency, please call emergency services immediately (911 in the US) or go to your nearest emergency room. This information is not a substitute for professional medical advice or treatment.\n\n';
    }
    
    // Based on the message, generate an appropriate response
    if (userMessage.toLowerCase().includes('headache')) {
      response += 'Headaches are common and can have various causes ranging from stress and dehydration to more serious conditions.\n\n';
      response += 'Common types include:\n• Tension headaches (most common)\n• Migraines\n• Cluster headaches\n• Sinus headaches\n\n';
      response += 'For occasional headaches, proper hydration, rest, and over-the-counter pain relievers may help. However, if you experience severe, sudden, or persistent headaches, it\'s important to consult with a healthcare provider for proper evaluation.\n\n';
      response += 'Remember that this information is educational and not a substitute for professional medical advice or diagnosis.';
    } 
    else if (userMessage.toLowerCase().includes('fever')) {
      response += 'A fever is typically defined as a body temperature above 98.6°F (37°C) and is often a sign that your body is fighting an infection.\n\n';
      response += 'Common causes include:\n• Viral infections\n• Bacterial infections\n• Inflammatory conditions\n• Certain medications\n\n';
      response += 'For mild fevers, rest, hydration, and fever-reducing medications may help manage symptoms. However, high fevers (above 103°F/39.4°C for adults) or fevers accompanied by severe symptoms warrant prompt medical attention.\n\n';
      response += 'Remember that this information is educational and not a substitute for professional medical advice or diagnosis.';
    }
    else if (userMessage.toLowerCase().includes('diet') || userMessage.toLowerCase().includes('nutrition')) {
      response += 'A balanced diet is fundamental to good health and includes a variety of nutrients from different food groups.\n\n';
      response += 'Key components of a healthy diet include:\n• Fruits and vegetables\n• Whole grains\n• Lean proteins\n• Healthy fats\n• Adequate hydration\n\n';
      response += 'Individual nutritional needs can vary based on age, sex, activity level, and underlying health conditions. A registered dietitian can provide personalized guidance for your specific situation.\n\n';
      response += 'Remember that this information is educational and not a substitute for professional medical advice or diagnosis.';
    }
    else {
      response += 'Thank you for your health-related question. As a medical AI assistant, I can provide general information on various health topics including conditions, symptoms, wellness strategies, and preventive care.\n\n';
      response += 'For personalized medical advice, diagnosis, or treatment recommendations, it\'s important to consult with a qualified healthcare provider who can consider your specific medical history and circumstances.\n\n';
      response += 'If you\'d like to ask about a specific health concern or topic, please feel free to provide more details, and I\'ll do my best to provide educational information on the subject.\n\n';
      response += 'Remember that this information is educational and not a substitute for professional medical advice or diagnosis.';
    }
    
    return response;
  }

  /**
   * Simulates text chunks for streaming by breaking a response into smaller pieces
   * This function is kept for reference but now replaced with server-sent events streaming
   * @param {string} text - The full text to be chunked
   * @returns {string[]} Array of text chunks
   * @private
   */
  // eslint-disable-next-line no-unused-vars
  function _simulateTextChunks(text) {
    // Simple chunking by sentences or punctuation
    const chunks = [];
    let currentPos = 0;
    const chunkSize = 20; // characters per chunk, adjust as needed
    
    while (currentPos < text.length) {
      // Try to find a good breaking point (sentence or punctuation)
      let endPos = Math.min(currentPos + chunkSize, text.length);
      
      // If we're not at the end, try to break at a natural point
      if (endPos < text.length) {
        // Look for natural break points like periods, commas, etc.
        const nextPeriod = text.indexOf('.', currentPos + 5);
        const nextComma = text.indexOf(',', currentPos + 5);
        const nextNewline = text.indexOf('\n', currentPos + 5);
        
        // Find the closest break point that's after currentPos+5 (to ensure some content)
        const breakPoints = [nextPeriod, nextComma, nextNewline]
          .filter(pos => pos > currentPos + 5 && pos <= currentPos + chunkSize * 2);
        
        if (breakPoints.length > 0) {
          // Use the closest break point
          endPos = Math.min(...breakPoints) + 1; // Include the punctuation
        }
      }
      
      chunks.push(text.substring(currentPos, endPos));
      currentPos = endPos;
    }
    
    return chunks;
  }

  apiRouter.post("/chat/stream", async (req, res) => {
    try {
      // Start timing the request for analytics
      const startTime = Date.now();
      
      // Generate a unique session ID if not provided
      const sessionId = req.headers['x-session-id'] || `session_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`;
      
      // Validate request body against schema
      const validation = chatRequestSchema.safeParse(req.body);
      
      if (!validation.success) {
        console.error(`[${sessionId}] Validation failed:`, validation.error);
        return res.status(400).json({
          success: false,
          message: "Invalid request data",
          errors: validation.error.errors,
        });
      }
      
      const { message, conversationHistory, isHighRisk } = validation.data;
      const config = getDeepSeekConfig();
      
      if (!config.apiKey) {
        console.error("Missing DeepSeek API key");
        return res.status(500).json({
          success: false,
          message: "DeepSeek API key is missing. Please set the DEEPSEEK_API_KEY environment variable.",
        });
      }

      // Set up SSE headers
      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache');
      res.setHeader('Connection', 'keep-alive');
      res.flushHeaders(); // Flush the headers to establish SSE connection

      // Log the incoming streaming request for analytics
      console.info(`[${sessionId}] Processing streaming chat request${isHighRisk ? ' (HIGH RISK)' : ''}: ${message.substring(0, 100)}${message.length > 100 ? '...' : ''}`);

      // Prepare messages for the LLM
      let promptMessages = [];
      
      // Add system message with safety instructions and role information
      promptMessages.push({
        role: "system",
        content: `You are Anamnesis, a medical AI assistant that provides health information and guidance. 
        ${isHighRisk ? 'IMPORTANT: The user may describe an urgent medical situation. Emphasize the importance of seeking immediate professional medical attention for emergencies.' : ''}
        Focus on providing accurate, evidence-based information while clearly acknowledging limitations.
        For any urgent or life-threatening situations, always advise users to contact emergency services immediately.`
      });
      
      // Add conversation history for context
      if (Array.isArray(conversationHistory) && conversationHistory.length > 0) {
        // Limit history to last 10 messages to avoid token limits
        const recentHistory = conversationHistory.slice(-10);
        promptMessages = [...promptMessages, ...recentHistory];
      }
      
      // Add the current user message
      promptMessages.push({
        role: "user",
        content: message
      });
      
      // Send the request to DeepSeek API with streaming enabled
      const deepSeekUrl = "https://api.deepseek.com/v1/chat/completions";
      
      // Send request with fetch in streaming mode
      const fetchResponse = fetch(deepSeekUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${config.apiKey}`
        },
        body: JSON.stringify({
          model: config.model || "deepseek-chat",
          messages: promptMessages,
          temperature: 0.7,
          max_tokens: 2000,
          stream: true
        }),
      });
      
      // Create timeout promise for API request
      const timeoutPromise = new Promise((_, reject) => {
        setTimeout(() => reject(new Error("Request timeout")), 30000);
      });
      
      try {
        // Race the promises
        const deepSeekResponse = await Promise.race([fetchResponse, timeoutPromise]);
        
        if (!deepSeekResponse.ok) {
          const errorText = await deepSeekResponse.text();
          console.error(`[${sessionId}] DeepSeek streaming API error:`, errorText);
          
          res.write(`data: ${JSON.stringify({ error: `API error: ${deepSeekResponse.status} ${deepSeekResponse.statusText}` })}\n\n`);
          res.end();
          return;
        }
        
        // Process the streaming response
        const reader = deepSeekResponse.body.getReader();
        const decoder = new TextDecoder("utf-8");
        
        let buffer = '';
        let responseText = '';
        
        // Save user and AI message to database
        const userId = req.user?.id || "anonymous";
        
        // Read the stream chunk by chunk
        while (true) {
          const { done, value } = await reader.read();
          
          if (done) {
            break;
          }
          
          // Decode the chunk
          buffer += decoder.decode(value, { stream: true });
          
          // Process complete lines in the buffer
          let lines = buffer.split('\n');
          buffer = lines.pop() || ''; // Keep the last partial line in the buffer
          
          for (const line of lines) {
            // Skip empty lines and :keep-alive comments
            if (!line || line.trim() === '' || line.startsWith(':')) {
              continue;
            }
            
            // Lines starting with "data:" contain the streamed content
            if (line.startsWith('data:')) {
              const jsonPart = line.slice(5).trim();
              
              // Check for the "[DONE]" marker
              if (jsonPart === '[DONE]') {
                continue;
              }
              
              try {
                const data = JSON.parse(jsonPart);
                const content = data.choices?.[0]?.delta?.content || '';
                
                if (content) {
                  // Accumulate response text
                  responseText += content;
                  
                  // Send the chunk to the client using event-based format for SSE
                  res.write(`event: chunk\ndata: ${JSON.stringify({ text: content })}\n\n`);
                  // Flush to ensure immediate delivery
                  if (res.flush) res.flush();
                }
              } catch (error) {
                console.error(`[${sessionId}] Error parsing chunk:`, error, jsonPart);
              }
            }
          }
        }
        
        // Finalize the streaming response
        const requestDuration = Date.now() - startTime;
        console.info(`[${sessionId}] Streaming response completed in ${requestDuration}ms`);
        
        // Save the messages to the database
        try {
          if (userId !== "anonymous" && responseText) {
            await storage.saveMessage(userId, message, responseText);
          }
        } catch (dbError) {
          console.error(`[${sessionId}] Error saving messages:`, dbError);
        }
        
        // Send configuration data for the client
        res.write(`event: config\ndata: ${JSON.stringify({
          model: config.model || "deepseek-chat",
          sessionId: sessionId,
          requestTime: requestDuration,
          tokensEstimate: Math.round(responseText.split(' ').length * 1.3)
        })}\n\n`);
        
        // Send completion event
        res.write(`event: done\ndata: ${JSON.stringify({
          completed: true,
          requestTime: requestDuration
        })}\n\n`);
        
        // End the response
        res.end();
      } catch (apiError) {
        console.error(`[${sessionId}] Streaming error:`, apiError);
        // Send error event with proper SSE formatting
        res.write(`event: error\ndata: ${JSON.stringify({ 
          error: apiError.message,
          code: 'streaming_error' 
        })}\n\n`);
        
        // Still send a done event to ensure client knows the stream is complete
        res.write(`event: done\ndata: ${JSON.stringify({
          completed: false,
          error: true,
          requestTime: Date.now() - startTime
        })}\n\n`);
        
        res.end();
      }
    } catch (error) {
      console.error("Streaming endpoint error:", error);
      
      // Check if headers have already been sent (we might have started streaming)
      if (!res.headersSent) {
        res.status(500).json({
          success: false,
          message: "An error occurred while processing your request",
          error: error.message
        });
      } else {
        // If headers were already sent, we need to use SSE format
        try {
          res.write(`event: error\ndata: ${JSON.stringify({ 
            error: error.message,
            code: 'request_error' 
          })}\n\n`);
          
          res.write(`event: done\ndata: ${JSON.stringify({
            completed: false,
            error: true,
            requestTime: Date.now() - startTime
          })}\n\n`);
        } catch (writeError) {
          console.error("Error sending error message via SSE:", writeError);
        }
        
        res.end();
      }
    }
  });

  // Register message API routes
  apiRouter.use("/messages", messageApiRouter);
  
  // Register direct endpoints with simpler routing structure
  apiRouter.use("/direct", directEndpoints);

  // Register API routes under /api prefix
  app.use("/api", apiRouter);

  const httpServer = createServer(app);
  return httpServer;
}