/**
 * @file Supabase connection test script
 * Tests the connection to Supabase and verifies auth functionality
 */

import { supabaseAdmin } from '../shared/supabase.js';
import { getConfig } from '../shared/config.js';

/**
 * Tests the Supabase connection and basic functionality
 * @returns {Promise<{success: boolean, message: string, data?: any, error?: string}>} Test result
 */
async function testSupabaseConnection() {
  console.log('Testing Supabase connection...');
  
  try {
    // First, validate that we have the required config
    const config = getConfig();
    console.log('Configuration loaded successfully', {
      url: config.supabase.url,
      hasAnonKey: !!config.supabase.anonKey,
      hasServiceKey: !!config.supabase.serviceKey,
      environment: config.app.env
    });
    
    // Test a simple query to verify connection
    const { data, error } = await supabaseAdmin.auth.admin.listUsers({
      page: 1,
      perPage: 10
    });
    
    if (error) {
      throw error;
    }
    
    console.log('Supabase connection successful!');
    console.log(`Retrieved ${data.users.length} users`);
    
    // Create test user if needed (for development only)
    if (config.app.isDev && data.users.length === 0) {
      console.log('No users found in development environment. You can create a test user by:');
      console.log('1. Using the registration form in the app');
      console.log('2. Using the Supabase dashboard');
    }
    
    // Test successful
    return {
      success: true,
      message: 'Supabase connection is working properly',
      data: {
        userCount: data.users.length,
        projectUrl: config.supabase.url
      }
    };
  } catch (error) {
    console.error('Supabase connection test failed:', error.message);
    
    // Give helpful instructions if it's a common error
    if (error.message.includes('invalid auth credentials')) {
      console.error('Error: Your Supabase service role key is invalid.');
      console.error('Please check your SUPABASE_SERVICE_KEY in .env or Replit Secrets.');
    } else if (error.message.includes('getaddrinfo ENOTFOUND')) {
      console.error('Error: Could not connect to Supabase URL.');
      console.error('Please check your SUPABASE_URL in .env or Replit Secrets.');
    } else if (error.message.includes('Environment variable')) {
      console.error('Error: Missing required environment variables.');
      console.error('Please set all required variables in .env or Replit Secrets.');
      console.error('See .env.example for the required variables.');
    }
    
    // Test failed
    return {
      success: false,
      message: 'Supabase connection test failed',
      error: error.message
    };
  }
}

// Run the test if this file is executed directly
if (process.argv[1].endsWith('test-connection.js')) {
  testSupabaseConnection()
    .then(result => {
      console.log('Test result:', result);
      if (!result.success) {
        process.exit(1);
      }
    })
    .catch(err => {
      console.error('Unhandled error in test:', err);
      process.exit(1);
    });
}

/**
 * Exports the testSupabaseConnection function for use in other modules
 * @module test-connection
 */
export default testSupabaseConnection;