/**
 * @file Configuration loading module for the Anamnesis Medical AI Assistant
 * Securely loads environment variables with proper validation
 */

/**
 * @typedef {object} SupabaseConfig
 * @property {string} url - Supabase project URL
 * @property {string} anonKey - Supabase anonymous public key
 * @property {string} serviceKey - Supabase service role key (server-side only)
 */

/**
 * @typedef {object} AppConfig
 * @property {string} env - Current environment (development/production)
 * @property {string} apiUrl - Backend API URL
 * @property {boolean} isDev - Whether the app is running in development mode
 */

/**
 * @typedef {object} Config
 * @property {SupabaseConfig} supabase - Supabase configuration
 * @property {AppConfig} app - Application configuration
 */

/**
 * Gets the required environment variable or throws a clear error
 * @param {string} name - Name of the environment variable
 * @param {string|null} [defaultValue=null] - Optional default value if not found
 * @param {boolean} [isRequired=true] - Whether the environment variable is required
 * @returns {string} The environment variable value
 * @throws {Error} If the required environment variable is missing
 */
function getEnvVar(name, defaultValue = null, isRequired = true) {
  const value = process.env[name] || defaultValue;
  
  if (isRequired && !value) {
    throw new Error(
      `Environment variable ${name} is required but not set. ` +
      `Please set it in your .env file or Replit Secrets.`
    );
  }
  
  return value;
}

/**
 * Loads configuration from environment variables
 * @returns {Config} Application configuration
 */
export function loadConfig() {
  const isDev = getEnvVar('NODE_ENV', 'development') === 'development';
  
  /** @type {Config} */
  const config = {
    supabase: {
      url: getEnvVar('SUPABASE_URL', null, true),
      anonKey: getEnvVar('SUPABASE_ANON_KEY', null, true),
      serviceKey: getEnvVar('SUPABASE_SERVICE_KEY', null, true)
    },
    app: {
      env: getEnvVar('NODE_ENV', 'development'),
      apiUrl: getEnvVar('API_URL', isDev ? 'http://localhost:5000' : '', false),
      isDev
    }
  };
  
  return config;
}

/**
 * Validates that all required configuration is present
 * @param {Config} config - The loaded configuration
 * @returns {boolean} Whether the configuration is valid
 * @throws {Error} If the configuration is invalid
 */
export function validateConfig(config) {
  // Validate Supabase configuration
  if (!config.supabase.url || !config.supabase.url.includes('supabase.co')) {
    throw new Error('Invalid SUPABASE_URL. Must be a valid Supabase project URL.');
  }
  
  if (!config.supabase.anonKey || config.supabase.anonKey.length < 20) {
    throw new Error('Invalid SUPABASE_ANON_KEY. Must be a valid Supabase key.');
  }
  
  if (!config.supabase.serviceKey || config.supabase.serviceKey.length < 20) {
    throw new Error('Invalid SUPABASE_SERVICE_KEY. Must be a valid Supabase service role key.');
  }
  
  return true;
}

/**
 * Gets the validated configuration
 * @returns {Config} The validated configuration
 */
export function getConfig() {
  const config = loadConfig();
  validateConfig(config);
  return config;
}

export default getConfig();