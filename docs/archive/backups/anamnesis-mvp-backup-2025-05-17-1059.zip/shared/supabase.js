/**
 * @file Supabase client module for the Anamnesis Medical AI Assistant
 * Provides authenticated Supabase clients for frontend and backend
 */

import { createClient } from '@supabase/supabase-js';
import config from './config.js';

/**
 * Creates a Supabase client with the provided credentials
 * @param {string} supabaseUrl - The Supabase project URL
 * @param {string} supabaseKey - The Supabase API key (anon or service role)
 * @param {object} [options={}] - Additional client options
 * @returns {import('@supabase/supabase-js').SupabaseClient} The Supabase client
 */
export function createSupabaseClient(supabaseUrl, supabaseKey, options = {}) {
  return createClient(supabaseUrl, supabaseKey, options);
}

/**
 * The frontend Supabase client using the anonymous key
 * Safe to use in browser code
 */
export const supabaseClient = createSupabaseClient(
  config.supabase.url,
  config.supabase.anonKey,
  {
    auth: {
      autoRefreshToken: true,
      persistSession: true
    }
  }
);

/**
 * The admin Supabase client using the service role key
 * WARNING: Only use on the server side, never expose to the client
 */
export const supabaseAdmin = createSupabaseClient(
  config.supabase.url,
  config.supabase.serviceKey
);

/**
 * Helper function to sign up with email and password
 * @param {string} email - User's email address
 * @param {string} password - User's password
 * @param {object} [metadata={}] - Additional user metadata
 * @returns {Promise<{user: object|null, error: Error|null}>} The sign up result
 */
export async function signUp(email, password, metadata = {}) {
  return supabaseClient.auth.signUp({
    email,
    password,
    options: {
      data: metadata
    }
  });
}

/**
 * Helper function to sign in with email and password
 * @param {string} email - User's email address
 * @param {string} password - User's password
 * @returns {Promise<{data: {user: object|null, session: object|null}, error: Error|null}>} The sign in result
 */
export async function signIn(email, password) {
  return supabaseClient.auth.signInWithPassword({
    email,
    password
  });
}

/**
 * Helper function to sign in with a third-party provider
 * @param {('google'|'microsoft'|'apple')} provider - The OAuth provider
 * @returns {Promise<{data: {url: string}, error: Error|null}>} The sign in URL
 */
export async function signInWithProvider(provider) {
  return supabaseClient.auth.signInWithOAuth({
    provider,
    options: {
      redirectTo: `${window.location.origin}/auth/callback`
    }
  });
}

/**
 * Helper function to sign out the current user
 * @returns {Promise<{error: Error|null}>} The sign out result
 */
export async function signOut() {
  return supabaseClient.auth.signOut();
}

/**
 * Helper function to get the current user session
 * @returns {Promise<{data: {session: object|null}, error: Error|null}>} The current session
 */
export async function getSession() {
  return supabaseClient.auth.getSession();
}

/**
 * Helper function to get the current user
 * @returns {Promise<{data: {user: object|null}, error: Error|null}>} The current user
 */
export async function getUser() {
  return supabaseClient.auth.getUser();
}

export default supabaseClient;